import request from 'supertest';
import express from "express";
import { vacationsRouter } from "../src/controllers/vacationControllers";
import { vacationImgRouters } from "../src/controllers/vacationImgControllers";
import { appConfig } from '../src/utils/appConfig';
import { closeDB } from '../src/DB/dal';


const valid_token_admin = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjoxLCJmaXJzdE5hbWUiOiJCYXJ1Y2giLCJsYXN0TmFtZSI6IkdhdnJpZWxvdiIsImVtYWlsIjoiYmFydWNoQGdtYWlsLmNvbSIsImlzQWRtaW4iOnRydWV9LCJpYXQiOjE3MzA3MjQyODZ9.T4NELI3q2dXPXWmjdCZtkpdItaw0PYvknBGu61fGRy0";

const app = express();
app.use(express.json());
app.use(vacationsRouter);
app.use(vacationImgRouters);

describe("Vacation controllers", () => {
    let vid: number | undefined;
  
    it("should return all vacations", async () => {
      const response = await request(app)
        .get(appConfig.routePrefix + '/vacations') 
        .set('Authorization', `Bearer ${valid_token_admin}`);
        expect(response.status).toBe(200);
        expect(response.body).toEqual(expect.arrayContaining([expect.objectContaining({ destination: expect.any(String) })]));
    });
  
    it("should return vacation by id", async () => {
        const response = await request(app)
        .get(appConfig.routePrefix + '/vacations/2')
        .set('Authorization', `Bearer ${valid_token_admin}`);
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('id');
        expect(response.body.id).toBe(2);
    });
  
    it("should create a new vacation", async () => {
        const newVacation = {
            destination: "osaka",
            description: "Beautiful beaches and nice weather",
            start_date: "2025-12-01 08:00",
            end_date: "2025-12-14 08:00",
            price: 1500
        };
        const response = await request(app)
            .post(appConfig.routePrefix + '/vacations') 
            .set('Authorization', `Bearer ${valid_token_admin}`)
            .send(newVacation);
        expect(response.status).toBe(201);
        expect(response.body).toHaveProperty('id'); 
        vid = response.body.id;
    });
    
    it("should update a vacation", async () => {
        const updatedVacation = {
            destination: "Hawaii Updated",
            description: "Updated description",
            start_date: "2026-12-01 08:00",
            end_date: "2026-12-14 08:00",
            price: 1600
        };
    
        const response = await request(app)
            .put(appConfig.routePrefix + '/vacations/' + vid) 
            .set('Authorization', `Bearer ${valid_token_admin}`)
            .send(updatedVacation);
    
        expect(response.status).toBe(200);
        expect(response.body.destination).toBe(updatedVacation.destination);
        expect(response.body.description).toBe(updatedVacation.description);
        expect(response.body.start_date).toBe(updatedVacation.start_date);
        expect(response.body.end_date).toBe(updatedVacation.end_date);
        expect(response.body.price).toBe(updatedVacation.price);
    });
  
    it("should delete a vacation", async () => {
      const response = await request(app)
        .delete(appConfig.routePrefix + '/vacations/' + vid) 
        .set('Authorization', `Bearer ${valid_token_admin}`);
  
        expect(response.status).toBe(200); 
    });
    afterAll(async () => {
        closeDB();
    })
});

