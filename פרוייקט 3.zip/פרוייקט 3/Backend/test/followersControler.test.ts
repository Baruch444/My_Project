import request from 'supertest';
import express from "express";
import { followersRouters } from '../src/controllers/followerControllers';
import { closeDB } from '../src/DB/dal';

const valid_token_client = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjozLCJmaXJzdE5hbWUiOiJQYXRyaWNrIiwibGFzdE5hbWUiOiJTdGFyIiwiZW1haWwiOiJwYXRyaWNrQGdtYWlsLmNvbSIsImlzQWRtaW4iOmZhbHNlfSwiaWF0IjoxNzMwNzI0MzQ0fQ.BApYW8nrYBFkWHuqmCZrGs5FWNoIjYN53C9AChAtO7g";

const app = express();
app.use(express.json());
app.use(followersRouters);

describe("Followers controller", () => {
    it("should add a like to a vacation", async () => {
        const userId = 10;  
        const vacationId = 19;  
        const response = await request(app)
            .post('/api/v1/followers')  
            .set('Authorization', `Bearer ${valid_token_client}`)  
            .send({ userId, vacationId });
        expect(response.status).toBe(201);  
        expect(response.body.message).toBe("Like added successfully.");
    });
    it("should remove a like from a vacation", async () => {
        const userId = 10;  
        const vacationId = 19;  
        const response = await request(app)
            .delete('/api/v1/followers') 
            .set('Authorization', `Bearer ${valid_token_client}`)  
            .send({ userId, vacationId });
        expect(response.status).toBe(200); 
        expect(response.body.message).toBe("Like remove successfully.");
    });
    it("should return true if user is following a vacation", async () => {
        const userId = 9;  
        const vacationId = 19; 
        const response = await request(app)
            .get(`/api/v1/follower?userId=${userId}&vacationId=${vacationId}`)
            .set('Authorization', `Bearer ${valid_token_client}`);
        expect(response.status).toBe(200); 
        expect(response.body.isFollowing).toBe(true); 
    });
    it("should return a list of liked vacations by user", async () => {
        const userId = 3;  
        const response = await request(app)
            .get(`/api/v1/followers-likedv/${userId}`)
            .set('Authorization', `Bearer ${valid_token_client}`);
    
        expect(response.status).toBe(200);  
        expect(Array.isArray(response.body)).toBe(true); 
        expect(response.body.length).toBeGreaterThan(0); 
    });

    afterAll(async () => {
        closeDB();
    })
});