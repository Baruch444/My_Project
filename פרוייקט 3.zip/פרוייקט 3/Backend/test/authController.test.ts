import request from 'supertest';
import express from "express";
import { closeDB } from '../src/DB/dal';
import { appConfig } from "../src/utils/appConfig";
import { authRouters } from '../src/controllers/userControllers';

const app = express();
app.use(express.json());
app.use(authRouters);

describe("Auth controllers", () => {
    it("should register a new user and return a token", async () => {
        const newUser = {
            firstName: "yopy",
            lastName: "dopy",
            email: "yopy@gmail.com",
            password: "123456",
            isAdmin: false
        };
        const res = await request(app)
            .post(appConfig.routePrefix + "/register")
            .send(newUser);
            expect(res.status).toBe(201); 
    });

    it("should login an existing user and return a token", async () => {
        const credentials = {
            email: "yopy@gmail.com",
            password: "123456"
        };
        const res = await request(app)
        .post(appConfig.routePrefix + "/login")
        .send(credentials);
        expect(res.status).toBe(200);
    });

    it("should return 401 for incorrect credentials", async () => {
        const credentials = {
            email: "yopy@gmail.com",
            password: "wrongpassword"
        };
        const res = await request(app)
            .post(appConfig.routePrefix + "/login")
            .send(credentials);
        expect(res.status).toBe(401);
    });
    
    it("should return 200 if email is available", async () => {
        const email = "available.email@gmail.com";
        const res = await request(app)
        .get(appConfig.routePrefix + "/check-email")
        .query({ email });
        expect(res.status).toBe(200);
        expect(res.body).toHaveProperty('message', 'Email is available');
    });
    
    it("should return 409 if email is already taken", async () => {
        const email = "baruch@gmail.com";
        const res = await request(app)
        .get(appConfig.routePrefix + "/check-email")
        .query({ email });
        expect(res.status).toBe(409);
        expect(res.body).toHaveProperty('message', 'Email is already taken');
    });

    it("should return 400 if email query is missing", async () => {
        const res = await request(app)
        .get(appConfig.routePrefix + "/check-email");
        expect(res.status).toBe(400);
        expect(res.body).toHaveProperty('message', 'Email is required');
    });
    
    it('should delete the user if token is valid', async () => {
        const email = "yopy@gmail.com"; 
        const res = await request(app)
            .delete(appConfig.routePrefix + `/delete_user`)
            .send({ email });  
        expect(res.status).toBe(200);
        expect(res.text).toBe('user deleted...');
    });
    
    afterAll(async () => {
        await closeDB();
    });
});
