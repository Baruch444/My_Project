import dotenv from "dotenv";
import path from "path";

dotenv.config();

class BaseAppConfig {
    readonly routePrefix = "/api/v1";
    readonly errorLogFile = path.join(__dirname, "..", "logs", "error.log");
    readonly accessLogFile = path.join(__dirname, "..", "logs", "access.log");
    readonly vacationsImagesPrefix = path.resolve(__dirname, "..", "assets", "images");
    readonly doormanKey = process.env.DOORMAN_KEY;
    readonly jwtSecrete = process.env.JWT_SECRET;

    readonly dbConfig = {               
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD
    }

}

class DevAppconfig extends BaseAppConfig {
    readonly port : number = 4000;      
    readonly dbConfig = {
        ...this.dbConfig,
        host: 'localhost',
        port: 3306,
        database: 'vacation',                
    };
}

export const appConfig = new DevAppconfig();
