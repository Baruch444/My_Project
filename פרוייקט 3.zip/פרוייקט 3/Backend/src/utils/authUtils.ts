import { UnauthorizedError, AppExcption } from "../models/exceptions";
import { UserModel } from "../models/userModel";
import { appConfig } from "./appConfig";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";


export function verifyToken(token: string, adminRequired?: boolean) {
    if (!token) throw new UnauthorizedError("Missing Credentials!");

    try {
        const res = jwt.verify(token, appConfig.jwtSecrete) as { userWithoutPassword: UserModel };
        if (adminRequired && !res.userWithoutPassword.isAdmin) {
            throw new UnauthorizedError("Only admin user has access 123!");
        }
        return res.userWithoutPassword;
    } catch (error) {
        console.error("Token Verification Error:", error); 
        if (error instanceof AppExcption) throw error;
        throw new UnauthorizedError("ERROR: Wrong Credentials!");
    }
}

export function createToken(user: UserModel): any {
    const userWithoutPassword = {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        isAdmin: user.isAdmin
    };
    const options = {};
    const token = jwt.sign({userWithoutPassword}, appConfig.jwtSecrete, options)
    console.log("Token payload:", userWithoutPassword);
    return token ;
};

export async function encryptPassword(password: string): Promise<string> {
    const epw = await bcrypt.hash(password, 10);
    return epw;
}

export async function validatePassword(
    password: string,
    hashedPassword: string
): Promise<boolean> {
    const res = await bcrypt.compare(String(password), hashedPassword);
    return res;
};
