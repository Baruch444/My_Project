import cors from "cors";
import express from "express";
import { logMW } from "./middlewares/logMW";
import { appConfig } from "./utils/appConfig";
import catchAll from "./middlewares/catchAll";
import { isDbServerUp } from "./utils/helpers";
// import expressRateLimit from "express-rate-limit";
import expressFileUpload from "express-fileupload";
import { authRouters } from "./controllers/userControllers";
import { vacationsRouter } from "./controllers/vacationControllers";
import { vacationImgRouters } from "./controllers/vacationImgControllers";
import { followersRouters } from "./controllers/followerControllers";

const server = express();

// server.use(expressRateLimit({
//     windowMs: 1000,
//     max: 2,
// }));

server.use(cors({origin: ["http://localhost:3000", "http://localhost:3001", "http://localhost:4000"]}));

server.use(logMW);

server.use(express.json());

server.use(expressFileUpload());

server.use("/", authRouters);
server.use("/", vacationsRouter);
server.use("/", vacationImgRouters);
server.use("/", followersRouters);

server.use(catchAll);

isDbServerUp().then((isUp) => {
    if (isUp) {
        server.listen(appConfig.port, () => {
            console.log(`Listening on http://localhost:${appConfig.port}`);
        })
    } else {
        console.error("\n\n****\nDB server is not up!!!\n****\n");
    }
});