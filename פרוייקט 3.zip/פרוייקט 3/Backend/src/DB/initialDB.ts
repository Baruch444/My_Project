import runQuery, { closeDB } from "./dal";

const createTables = async () => {
    let query = `
        CREATE TABLE IF NOT EXISTS users  (
            id INT AUTO_INCREMENT PRIMARY KEY,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            email VARCHAR(50) UNIQUE NOT NULL ,
            password VARCHAR(255) NOT NULL,
            isAdmin BOOLEAN DEFAULT false,
            token VARCHAR(500)
        )
    `;
    await runQuery(query);
    query = `
        CREATE TABLE IF NOT EXISTS vacations  (
            id INT AUTO_INCREMENT PRIMARY KEY,
            destination VARCHAR(50) NOT NULL,
            description VARCHAR(1000) NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            price DECIMAL(10, 2) NOT NULL
        )
    `;
    await runQuery(query);
    query = `
        CREATE TABLE IF NOT EXISTS vacations_image  (
            id INT AUTO_INCREMENT PRIMARY KEY,
            vacation_id INT NOT NULL,
            image_path VARCHAR(255) NOT NULL,
            FOREIGN KEY (vacation_id) REFERENCES vacations(id)
        );
    `
    await runQuery(query);
    query = `
        CREATE TABLE IF NOT EXISTS followers  (
            user_id INT NOT NULL,
            vacation_id INT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (vacation_id) REFERENCES vacations(id)
        );
    `
    await runQuery(query);
}

const createSampleData = async () => {
    // let query = `
    //     INSERT INTO users (first_name, last_name, email, password) VALUES
    //     ('John', 'Doe', 'johndoe@gmail.com', '123456'),
    //     ('Jane', 'Smith', 'janesmith@gmail.com', '123456'),
    //     ('Michael', 'Johnson', 'michaelj@gmail.com', '123456'),
    //     ('Emily', 'Davis', 'emilydavis@gmail.com', '123456')
    // `;
    // await runQuery(query);

    // query = `
    //     INSERT INTO users (first_name, last_name, email, password, isAdmin) VALUES
    //     ('Baruch', 'Gavrielov', 'baruch@gmail.com', '123456', true),
    //     ('Bart', 'Simpson', 'bart@gmail.com', '123456', true)
    // `;
    // await runQuery(query);
    let query = `
        INSERT INTO vacations (destination, description, start_date, end_date, price) VALUES
        ('Paris', 'Enjoy the beauty of Paris', '2025-09-15 08:00:00', '2025-09-22 20:00:00', 1500.00),
        ('Rome', 'Explore ancient Rome', '2025-10-05 10:00:00', '2025-10-12 18:00:00', 1200.00),
        ('London', 'Discover the wonders of London', '2025-11-01 09:00:00', '2025-11-08 17:00:00', 1300.00),
        ('New York', 'Experience the excitement of NYC', '2025-12-20 10:00:00', '2025-12-27 19:00:00', 1800.00),
        ('Tokyo', 'Explore Tokyo culture and technology', '2025-01-10 08:00:00', '2025-01-17 22:00:00', 2000.00),
        ('Sydney', 'Visit the iconic Sydney Opera House', '2025-02-15 09:00:00', '2025-02-22 20:00:00', 1700.00),
        ('Dubai', 'Luxury vacation in Dubai', '2025-03-10 08:00:00', '2025-03-17 21:00:00', 2500.00),
        ('Barcelona', 'Marvel at Gaudi masterpieces in Barcelona', '2025-04-05 09:00:00', '2025-04-12 18:00:00', 1600.00),
        ('Berlin', 'Dive into Berlin rich history', '2025-05-01 08:00:00', '2025-05-08 19:00:00', 1400.00),
        ('Amsterdam', 'Enjoy the canals of Amsterdam', '2025-06-10 08:00:00', '2025-06-17 20:00:00', 1500.00),
        ('Bangkok', 'Adventure in vibrant Bangkok', '2025-07-01 08:00:00', '2025-07-08 21:00:00', 1000.00),
        ('Los Angeles', 'Sunshine and glamour in LA', '2025-08-15 10:00:00', '2025-08-22 19:00:00', 1900.00),
        ('Mexico City', 'Experience Mexico City history and culture', '2025-09-05 09:00:00', '2025-09-12 20:00:00', 1100.00),
        ('Athens', 'Explore the cradle of civilization in Athens', '2025-10-01 08:00:00', '2025-10-08 20:00:00', 1350.00),
        ('Cairo', 'Visit the Great Pyramids of Giza', '2025-11-05 10:00:00', '2025-11-12 21:00:00', 1250.00),
        ('Moscow', 'Discover the culture of Moscow', '2025-12-01 08:00:00', '2025-12-08 18:00:00', 1450.00),
        ('Cape Town', 'Visit the natural wonders of Cape Town', '2026-01-10 09:00:00', '2026-01-17 19:00:00', 1700.00),
        ('Rio de Janeiro', 'Enjoy the vibrant city of Rio', '2026-02-05 08:00:00', '2026-02-12 20:00:00', 1600.00),
        ('Lisbon', 'Explore Lisbon stunning coastlines', '2026-03-15 09:00:00', '2026-03-22 21:00:00', 1550.00),
        ('Istanbul', 'Cross between Europe and Asia in Istanbul', '2026-04-01 08:00:00', '2026-04-08 20:00:00', 1450.00);
    `;
    await runQuery(query);
}


// createTables().then(() => {
//     console.log("Done creating tables");
//     closeDB();
// })
// createSampleData().then(() => {
//         console.log("Done creating data");
//         closeDB();
// });
