import { UploadedFile } from "express-fileupload";
import runQuery from "../DB/dal";
import { saveImage } from "../utils/helpers";

export async function getVacationImg(vid:number) {
    try {
        const query = `SELECT image_path FROM vacations_image WHERE vacation_id=? limit 1;`;
        const res = await runQuery(query, [vid]);
        if (res.length === 0) throw new Error(`No images found...`);
        return res.map((x) => x.image_path);
    } catch (error) {
        throw new Error(`Error retrieving images: ${error.message}`);
    }
};

export async function saveVacationImg(vacation_id:number, image:UploadedFile) {
    try {
        const imgFileName = await saveImage(image);
        let query = `SELECT image_path FROM vacations_image WHERE vacation_id = ?;`;
        const existingImage = await runQuery(query, [vacation_id]);
        if (existingImage.length > 0) {
            query = `DELETE FROM vacations_image WHERE vacation_id = ?;`;
            await runQuery(query, [vacation_id]);
        }
        query = `INSERT INTO vacations_image (vacation_id, image_path) VALUES (?, ?);`;
        const res: any = await runQuery(query, [vacation_id, imgFileName]);
        if (res.affectedRows === 0) throw new Error(`Failed to save image...`);
        return imgFileName;
    } catch (error) {
        throw new Error(`Error saving image: ${error.message}`);
    }
};

export async function deleteImgV(vid:number) {
    const qImage = `DELETE FROM vacations_image WHERE vacation_id = ?;`;
    await runQuery(qImage, [vid]);
}