import runQuery from "../DB/dal";
import { ValidationError } from "../models/exceptions";
import VacationModel from "../models/vacationModel";

export async function getVacationsPaginated(page: number, limit: number): Promise<VacationModel[]> {
    const offset = (page - 1) * limit;
    const q = `
        SELECT 
            vacations.id,
            vacations.destination,
            vacations.description,
            vacations.start_date,
            vacations.end_date,
            vacations.price,
            vacations_image.image_path 
        FROM vacations
        LEFT JOIN vacations_image 
        ON vacations.id = vacations_image.vacation_id
        LIMIT ? OFFSET ?;
    `;
    
    const res = await runQuery(q, [limit, offset]);

    const vacations = res.map((v) => new VacationModel(v));
    return vacations;
}

export async function getVacations(id?: number): Promise<VacationModel[]> {
    let q = `
        SELECT 
            vacations.id,
            vacations.destination,
            vacations.description,
            vacations.start_date,
            vacations.end_date,
            vacations.price,
            vacations_image.image_path 
        FROM vacations
        LEFT JOIN vacations_image 
        ON vacations.id = vacations_image.vacation_id
    `;
    if (id) {
        q += ` WHERE vacations.id = ?`;
    }
    
    const res = await runQuery(q, id ? [id] : []);    

    if (res.length === 0 && id) throw new Error("Vacation id not found");
    
    const vacations = res.map((v: any) => new VacationModel(v));
    return vacations;
}

export async function addVacation(v: VacationModel, imagePath: string) {
    v.validate();
    const query = `INSERT INTO vacations (destination, description, start_date, end_date, price)
    VALUES (?,?,?,?,?);`;
    let params = [v.destination, v.description, v.start_date, v.end_date, v.price];
    await runQuery(query, params);
    const res = await runQuery("SELECT LAST_INSERT_ID() as id;");
    const vacationId = res[0].id;

    if (imagePath) {
        const imageQuery = `
            INSERT INTO vacations_image (vacation_id, image_path)
            VALUES (?, ?);
        `;
        let imageParams = [vacationId, imagePath];
        await runQuery(imageQuery, imageParams);
    }
    return vacationId;
}

export async function updateVacation(v: Partial<VacationModel>, id: number) {
    if(! v.destination && !v.description && !v.start_date && !v.end_date && !v.price && !v.imageUrls){
        throw new ValidationError("No field specified to update!");
    }
    let vacations = await getVacations(id);
    const existingVacation = vacations[0];
    const updatedVacation = new VacationModel({ ...existingVacation, ...v });
    updatedVacation.validate();
    const params = [v.destination || existingVacation.destination, 
                            v.description || existingVacation.description, 
                            v.start_date || existingVacation.start_date, 
                            v.end_date || existingVacation.end_date, 
                            v.price || existingVacation.price, 
                            id];
    const updateQuery = `
    UPDATE vacations SET destination = ?, description = ?,  start_date = ?, end_date = ?, price = ?
    WHERE id = ?;`;
    await runQuery(updateQuery, params)
    
    if (v.imageUrls) {
        const imageUpdateQuery = `
            INSERT INTO vacations_image (vacation_id, image_path)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE image_path = VALUES(image_path);
        `;
        await runQuery(imageUpdateQuery, [id, v.imageUrls]);
    }
}

export async function deleteVacation(vid: number) {
    const qImage = `DELETE FROM vacations_image WHERE vacation_id = ?;`;
    await runQuery(qImage, [vid]);
    const qVacation = `DELETE FROM vacations WHERE id = ?;`;
    await runQuery(qVacation, [vid]);
}