import runQuery from "../DB/dal";
import { ResultSetHeader } from "mysql2";
import { UserModel } from "../models/userModel";
import { UnauthorizedError } from "../models/exceptions";
import { createToken, encryptPassword, validatePassword } from "../utils/authUtils";

export async function createUser(user:UserModel) {
    user.validate();
    const hashedPassword = await encryptPassword(user.password);
    if (user.isAdmin === undefined || user.isAdmin === null) user.isAdmin = false;
    let q = `INSERT INTO users (first_name, last_name, email, password, isAdmin) values (?, ?, ?, ?, ?);`;
    let params = [user.firstName, user.lastName, user.email, hashedPassword, user.isAdmin];
    const insertedInfo = (await runQuery(q, params)) as ResultSetHeader | any;
    const userId = insertedInfo.insertId;
    user.id = userId;
    user.token = createToken(user);
    q = `UPDATE users SET token=? WHERE id=?;`;
    params = [user.token, userId];
    await runQuery(q, params);

    return user.token;
}

export async function login(email: string, password: string) {
    let query = `SELECT * FROM users WHERE email=?;`;
    const res = await runQuery(query, [email]);
    if(res.length === 0) throw new UnauthorizedError("Wrong credentials1");
    const user = new UserModel(res[0]);    
    
    const isValidPassword = await validatePassword(password, res[0].password);

    if(!isValidPassword) throw new UnauthorizedError("Wrong credentials2");

    if(!user.token) {
        user.token = createToken(user);
        query = `UPDATE users SET token=? WHERE id=?;`;
        await runQuery(query, [user.token, user.id])
    }
    return user.token;
}

export async function isEmailTaken(email: string) {
    const query = `SELECT COUNT(*) as count FROM users WHERE email = ?`;
    const res = await runQuery(query, [email]);
    return res[0].count > 0;
}

export async function deleteUser(email:string) {
    const query = "DELETE FROM users WHERE email = ?;";
    await runQuery(query, [email]);
}