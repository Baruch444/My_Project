import runQuery from "../DB/dal";

class FollowerService {
    public async addLike(userId: number, vacationId: number): Promise<void> {
        const query = 'INSERT INTO followers (user_id, vacation_id) VALUES (?, ?)'; 
        await runQuery(query, [userId, vacationId]); 
    }
    public async removeLike(userId: number, vacationId: number){
        const query = 'DELETE FROM followers WHERE user_id = ? AND vacation_id = ?';
        await runQuery(query, [userId, vacationId])
    }
    public async getVacationLikes(): Promise<any[]> { 
        const query = `
            SELECT v.id AS vacation_id, v.destination, COUNT(f.user_id) AS like_count
            FROM vacations v
            LEFT JOIN followers f ON v.id = f.vacation_id
            GROUP BY v.id
        `;
        const res = await runQuery(query);
        return res; 
    }
    public async getVacationLikesCount(): Promise<any[]> { 
        const query = `
            SELECT v.id AS vacation_id, COUNT(f.user_id) AS like_count
            FROM vacations v
            LEFT JOIN followers f ON v.id = f.vacation_id
            GROUP BY v.id
        `;
        const res = await runQuery(query);
        return res; 
    }
    public async isUserFollowing(userId: number, vacationId: number): Promise<boolean> {
        const query = 'SELECT 1 FROM followers WHERE user_id = ? AND vacation_id = ? LIMIT 1';
        const res = await runQuery(query, [userId, vacationId]);
        return res.length > 0;
    }
    public async blah(userId: number, vacationId: number): Promise<boolean> {
        const query = `
            SELECT v.id AS vacation_id FROM followers f JOIN vacations v ON f.vacation_id = v.id WHERE v.id = ? AND f.user_id = ?`;
    
        const res = await runQuery(query, [vacationId, userId]);
        
        return res.length > 0;
    }
    public async getLikedVacations(userId: number): Promise<any[]> {
        const query = `
            SELECT v.id, v.destination, v.start_date, v.end_date, v.price
            FROM vacations v
            JOIN followers f ON v.id = f.vacation_id
            WHERE f.user_id = ?
        `;
        const res = await runQuery(query, [userId]);
        return res;
    }
}




export default new FollowerService();