import { Request, Response, NextFunction } from "express";
import { verifyToken } from "../utils/authUtils";
import { UnauthorizedError } from "../models/exceptions";

export function verifyTokenMW(req: Request, res: Response, next: NextFunction) {
    try {
        const token = req.header("Authorization")?.split(" ")[1];
        const user = verifyToken(token);
        res.locals.user = user;
        next()
    } catch (error) {
        next(error);
    }
}

export function verifyToekenAdminMW(req: Request, res: Response, next: NextFunction) {
    try {
        
        const token = req.header("Authorization")?.split(" ")[1];       
        const user = verifyToken(token, true);
        if (!user.isAdmin) {
            throw new UnauthorizedError("Only admin user has!");
        }
        res.locals.user = user;
        next()
    } catch (error) {
        next(error);
    }
}