import { Request, Response, NextFunction, Router } from "express";
import { appConfig } from "../utils/appConfig";
import { UserModel } from "../models/userModel";
import { createUser, deleteUser, isEmailTaken, login } from "../services/authService";
import { StatusCode } from "../models/statusEnum";

export const authRouters = Router();

authRouters.post(appConfig.routePrefix + "/register", 
    async (req: Request, res: Response, next: NextFunction)=>{
    try {
        const user = new UserModel(req.body);
        const token = await createUser(user);
        res.status(StatusCode.Created).json(token);
    } catch (error) {
        next(error)
    }
});

authRouters.post(appConfig.routePrefix + "/login", 
    async (req: Request, res: Response, next: NextFunction)=>{
    try {
        const email = req.body.email;
        const password = req.body.password;
        const token = await login(email, password);
        res.status(StatusCode.Ok).json(token);
    } catch (error) {
        next(error);
    }
});

authRouters.get(appConfig.routePrefix + "/check-email", 
    async (req: Request, res: Response, next: NextFunction)=>{
        try {
            const { email } = req.query;
            if (!email) {
                return res.status(StatusCode.BadRequest).json({ message: "Email is required" });
            }
            const isTaken = await isEmailTaken(email as string);
            if (isTaken) {
                return res.status(409).json({ message: "Email is already taken" });
            }
            return res.status(200).json({ message: "Email is available" });
    } catch (error) {
        next(error);
    }
});

authRouters.delete(appConfig.routePrefix + "/delete_user", 
    async (req: Request, res: Response, next: NextFunction)=> {
        try {
            const { email } = req.body; 
            if (!email) {
                return res.status(StatusCode.BadRequest).json({ message: "Email is required" });
            }
            await deleteUser(email);  
            res.status(StatusCode.Ok).send("user deleted...");
        } catch (error) {
            next(error);
        }
});
