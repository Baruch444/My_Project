import { Request, Response, NextFunction, Router } from "express";
import { appConfig } from "../utils/appConfig";
import followerService from "../services/followerService";
import runQuery from "../DB/dal";
import { verifyToekenAdminMW, verifyTokenMW } from "../middlewares/authMiddlewares";
import { StatusCode } from "../models/statusEnum";

export const followersRouters = Router();

followersRouters.post(appConfig.routePrefix + "/followers", verifyTokenMW,
    async (req: Request, res: Response, next: NextFunction) => {
        const { userId, vacationId } = req.body; 
        try {
            await followerService.addLike(userId, vacationId); 
            res.status( StatusCode.Created).json({ message: "Like added successfully." }); 
        } catch (error) {
            next(error); 
        }
    }
);

followersRouters.delete(appConfig.routePrefix + "/followers", verifyTokenMW,
    async (req: Request, res: Response, next: NextFunction) => {
        const { userId, vacationId } = req.body; 
        try {
            await followerService.removeLike(userId, vacationId); 
            res.status(StatusCode.Ok).json({ message: "Like remove successfully." }); 
        } catch (error) {
            next(error); 
        }
    }
);

followersRouters.get(appConfig.routePrefix + '/followers/:userId', verifyTokenMW,
    async (req: Request, res: Response, next: NextFunction) => {
    const userId = req.params.userId;
    try {
        const query = 'SELECT * FROM followers WHERE user_id = ?'; 
        const results = await runQuery(query, [userId]);
        res.status(StatusCode.Ok).json(results);
    } catch (error) {
        next(error);
    }
});


followersRouters.get(appConfig.routePrefix + '/followers', verifyTokenMW,
    async (req: Request, res: Response, next: NextFunction) => {
    try {
        const followData = await followerService.getVacationLikes(); 
        res.status(StatusCode.Ok).json(followData);
    } catch (error) {
        next(error);
    }
});

followersRouters.get(appConfig.routePrefix + '/follower-count', verifyTokenMW ,
    async (req: Request, res: Response, next: NextFunction) => {
    try {
        const followCount = await followerService.getVacationLikesCount(); 
        res.status(StatusCode.Ok).json(followCount);
    } catch (error) {
        next(error);
    }
});

followersRouters.get(appConfig.routePrefix + '/follower', verifyTokenMW,
    async (req: Request, res: Response, next: NextFunction) => {
    try {
        const userId = Number(req.query.userId); 
        const vacationId = Number(req.query.vacationId);
        if (isNaN(userId) || isNaN(vacationId)) {
            return res.status(StatusCode.BadRequest).json({ message: "Invalid userId or vacationId" });
        }
        const isFollowing = await followerService.blah(userId, vacationId); 
        res.status(StatusCode.Ok).json({ success: true, isFollowing }); 
    } catch (error) {
        next(error);
    }
});

followersRouters.get(appConfig.routePrefix + "/followers-likedv/:userId", verifyTokenMW,
    async (req: Request, res: Response, next: NextFunction) => {
    const userId = Number(req.params.userId);  
    try {
        const likedVacations = await followerService.getLikedVacations(userId);
        res.status(StatusCode.Ok).json(likedVacations); 
    } catch (error) {
        next(error);
    }
});
