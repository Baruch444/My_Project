import express, { Request, Response, NextFunction } from "express";
import { addVacation, deleteVacation, getVacations, getVacationsPaginated, updateVacation } from "../services/vacationService";
import { appConfig } from "../utils/appConfig";
import { StatusCode } from "../models/statusEnum";
import VacationModel from "../models/vacationModel";
import { verifyToekenAdminMW, verifyTokenMW } from "../middlewares/authMiddlewares";
import followerService from "../services/followerService";
import { parse } from 'json2csv';

export const vacationsRouter = express.Router();

vacationsRouter.get(appConfig.routePrefix + "/vacations-pg", verifyTokenMW,
    async (req: Request, res: Response, next: NextFunction) => {
        try {
            const { page = 0, limit = 10 } = req.query;
            const vacations = await getVacationsPaginated(+page, +limit);
            res.status(StatusCode.Ok).json(vacations);
        } catch (error) {
            next(error);
        }
    }
);

vacationsRouter.get(appConfig.routePrefix + "/vacations", verifyTokenMW,
    async (req: Request, res: Response, next: NextFunction) => {
    try {
        const vacations = await getVacations();
        res.status(StatusCode.Ok).json(vacations);
    } catch (error) {
        next(error);
    }
});

vacationsRouter.get(appConfig.routePrefix + "/vacations/:id", verifyTokenMW,
    async (req: Request, res: Response, next: NextFunction) => {
    try {
        const vacations = await getVacations(+req.params.id);
        if (vacations.length === 0) throw new Error("vacation id not found");
        res.status(StatusCode.Ok).json(vacations[0]);
    } catch (error) {
        if(error.message.includes("vacation id not found")){
            res.status(StatusCode.NotFound).send("Id not found!!!");
        } else {
            next(error);
        }
    }
});

vacationsRouter.post(appConfig.routePrefix + "/vacations", verifyToekenAdminMW,
    async (req: Request, res: Response, next: NextFunction) => {
    try {
        const newVacation = new VacationModel(req.body);
        const vacationId = await addVacation(newVacation, newVacation.imageUrls);
        res.status(StatusCode.Created).send({id: vacationId});
    } catch (error) {
        next(error);
    }
});

vacationsRouter.put(appConfig.routePrefix + "/vacations/:id", verifyToekenAdminMW,
    async (req: Request, res: Response, next: NextFunction) => {
    try {
        await updateVacation(req.body, +req.params.id);
        res.status(StatusCode.Ok).send(req.body);
    } catch (error) {
        next(error);
    }
});

vacationsRouter.delete(appConfig.routePrefix + "/vacations/:id", verifyToekenAdminMW,
    async (req: Request, res: Response, next: NextFunction) => {
    try {
        const vacationId = +req.params.id;
        await deleteVacation(vacationId);
        res.status(StatusCode.Ok).send("vacation deleted...");
    } catch (error) {
        next(error);
    }
});

vacationsRouter.get(appConfig.routePrefix + "/vacations/report/csv", verifyToekenAdminMW,
    async (req: Request, res: Response, next: NextFunction) => {
    try {
        const vacationLikes = await followerService.getVacationLikes();
        const csv = parse(vacationLikes, { fields: ['destination', 'like_count'] });
        
        res.header('Content-Type', 'text/csv');
        res.attachment('vacation_report.csv');
        res.send(csv);
    } catch (error) {
        next(error);
    }
});

