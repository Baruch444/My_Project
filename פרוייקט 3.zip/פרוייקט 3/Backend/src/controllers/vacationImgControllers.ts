import { deleteImgV, getVacationImg, saveVacationImg } from "../services/vacationImgServices";
import { NextFunction, Request, Response, Router } from "express";
import { StatusCode } from "../models/statusEnum";
import { UploadedFile } from "express-fileupload";
import { appConfig } from "../utils/appConfig";
import path from "path";
import fs from "fs";

export const vacationImgRouters = Router();

vacationImgRouters.get(appConfig.routePrefix + "/images/:vid",
    async (req: Request, res: Response, next: NextFunction) => {
        const vid = +req.params.vid;
        const images = await getVacationImg(vid);
        res.status(StatusCode.Ok).json(images);
    }
);

vacationImgRouters.get(appConfig.routePrefix + "/image/:imageId",
    async (req: Request, res: Response, next: NextFunction) => {
        try {
            const fullpath = path.join(appConfig.vacationsImagesPrefix, req.params.imageId);
            if (!fs.existsSync(fullpath)) {
                res.status(StatusCode.NotFound).send("Image not found");
                return;
            }
            res.sendFile(fullpath);
        } catch (error) {
            next(error);
        }
    }
);

vacationImgRouters.post(appConfig.routePrefix + "/image/:vacation_id",
    async (req: Request, res: Response, next: NextFunction) => {
        try {
            const vid = +req.params.vacation_id;
            const image = req.files?.image as UploadedFile;
            if(!image){
                res.status(StatusCode.BadRequest).send("missing image...");
                return;
            }
            const imgName = await saveVacationImg(vid, image);
            res.status(StatusCode.Created).send(imgName);
        } catch (error) {
            next(error);
        }
    }
);

vacationImgRouters.delete(appConfig.routePrefix + "/images/:vid",
    async (req: Request, res: Response, next: NextFunction) => {
        const { vid } = req.params;
        try {
            await deleteImgV(Number(vid)); 
            res.status(204).send(); 
        } catch (error) {
            next(error); 
        }
    }
);
