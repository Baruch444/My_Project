import Joi from 'joi';
import { ValidationError } from './exceptions';
import { format } from 'date-fns-tz';

class VacationModel {
    public id?: number;
    public destination: string;
    public description: string;
    public start_date: string;
    public end_date: string;
    public price: number;
    public imageUrls: string;

    constructor(vacation: any) {
        const timeZone = 'Asia/Jerusalem';
        this.id = vacation.id;
        this.destination = vacation.destination;
        this.description = vacation.description;
        this.start_date = format(new Date(vacation.start_date), 'yyyy-MM-dd HH:mm:ss', { timeZone });
        this.end_date = format(new Date(vacation.end_date), 'yyyy-MM-dd HH:mm:ss', { timeZone });
        this.price = vacation.price;
        this.imageUrls = vacation.imageUrls;
    }

    private static validateSchema = Joi.object({
        id: Joi.number().optional(),
        destination: Joi.string().min(2).max(50).required(),
        description: Joi.string().min(10).max(1000).required(),
        start_date: Joi.date().greater('now').required(),
        end_date: Joi.date().greater(Joi.ref('start_date')).required(),
        price: Joi.number().min(0).required(),
        imageUrls: Joi.string().uri().allow("").default("")
    });

    validate(): void {
        const res = VacationModel.validateSchema.validate(this);
        if (res.error) {
            throw new ValidationError(res.error.details[0].message);
        }
    }
}

export default VacationModel;