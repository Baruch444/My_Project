import Joi from 'joi';
import { ValidationError } from './exceptions';

export class UserModel {
    public id?: number;        
    public firstName: string;  
    public lastName: string;   
    public email: string;      
    public password?: string;  
    public isAdmin: boolean;   
    public token?: string;     

    constructor(user: Partial<UserModel>) { 
        this.id = user.id;
        this.firstName = user.firstName;
        this.lastName = user.lastName;
        this.email = user.email;
        this.password = user.password;
        this.isAdmin = user.isAdmin ?? false; 
        this.token = user.token;
    }

    private static validateSchema = Joi.object({
        id: Joi.number().optional(),
        firstName: Joi.string().min(2).max(50).required(),
        lastName: Joi.string().min(2).max(50).required(),
        email: Joi.string().email().required(),
        password: Joi.string().min(4).optional(), 
        isAdmin: Joi.boolean(),
        token: Joi.string().optional() 
    });

    validate(): void {
        const { error } = UserModel.validateSchema.validate(this);
        if (error) {
            throw new ValidationError(error.details[0].message);
        }
    }
    
}
