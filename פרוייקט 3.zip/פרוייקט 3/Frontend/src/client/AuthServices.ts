import axios from "axios";
import { register, logout, login } from "../redux/slices/authSlice";
import { store } from "../redux/store";
import CredentialsModel from "../models/CredentialsModel";
import UserModel from "../models/UserModel";
import { fetchVacations } from "../redux/slices/VacationsSlice";
import { jwtDecode } from "jwt-decode";
import { parseJwt } from "../utils/helpers";

class AuthServices {
    public async register(user: UserModel): Promise<string> {
        const response = await axios.post<string>("http://localhost:4000/api/v1/register/", user);
        const token = response.data;
    
        if (token) {
            store.dispatch(register(token)); 
        } else {
            throw new Error("No token received.");
        }
        return token;
    }
    public async checkEmailAvailability(email: string): Promise<boolean> {
        try {
            const response = await axios.get("http://localhost:4000/api/v1/check-email", {
                params: { email }
            });
            return response.status === 200;
        } catch (error) {
            if (axios.isAxiosError(error) && error.response && error.response.status === 409) {
                return false;
            }
            console.error("Error checking email availability:", error);
            throw error;
        }
    }
    public async login(credentials: CredentialsModel): Promise<UserModel | null> {
        try {
            const response = await axios.post<string>("http://localhost:4000/api/v1/login/", credentials);
            const token = response.data;
            store.dispatch(login(token)); 
            const parsedToken = parseJwt(token);
            if (parsedToken && parsedToken.userWithoutPassword) {
                return parsedToken.userWithoutPassword;
            } else {
                console.error("Token parsing failed: No user data found in token.");
                throw new Error("Failed to parse user from token.");
            }
        } catch (error: any) {
            if (error.response && error.response.data && error.response.data.message) {
                throw new Error(error.response.data.message); 
            }
            throw new Error("Login failed. Please check your credentials.");
        }
    }
    public logout(): void {
        store.dispatch(logout());
        store.dispatch(fetchVacations([]));
        localStorage.removeItem("user");
    }
    public getUserFromToken(token: string): UserModel {
        try {
            const container: { userWithoutPassword: UserModel } = parseJwt(token);
            return container.userWithoutPassword;
        } catch (error) {
            console.error("Error decoding token:", error);
            return null;
        }
    }
}

const authService = new AuthServices();
export default authService;