import axios from "axios";
import { VacationModel } from "../models/VacationModel";

export const getAuthHeaders = () => {
    const token = localStorage.getItem("token"); 
    return {
        headers: {
            Authorization: `Bearer ${token}` 
        }
    };
};

export async function getAllVacationsPaginated(page: number, limit: number = 10): Promise<VacationModel[]> {
    try {
        const res = await axios.get<VacationModel[]>(`http://localhost:4000/api/v1/vacations-pg?page=${page}&limit=${limit}`, getAuthHeaders());
        return res.data;
    } catch (error) {
        console.error("Error fetching vacations:", error);
        throw error;
    }
}

export async function getAllVacations(): Promise<VacationModel[]> {
    try {
        const res = await axios.get<VacationModel[]>('http://localhost:4000/api/v1/vacations', getAuthHeaders());
        return res.data;
    } catch (error) {
        console.error("Error fetching vacations:", error);
        throw error;
    }
}

export async function getVacationById(id:number): Promise<VacationModel> {
    try {
        const res = await axios.get<VacationModel>(`http://localhost:4000/api/v1/vacations/${id}`, getAuthHeaders());
        return res.data;
    } catch (error) {
        console.error("Error fetching vacations:", error);
        throw error;
    }
}

export async function addVacation(vacation: VacationModel): Promise<number> {
    const res = await axios.post('http://localhost:4000/api/v1/vacations', vacation, getAuthHeaders());
    return res.data.id;  
}

export async function addVacationImage(vacationId: number, image: File): Promise<void> {
    const formData = new FormData();
    formData.append("image", image); 

    await axios.post(`http://localhost:4000/api/v1/image/${vacationId}`, formData, {
        ... getAuthHeaders(),
        headers: {
            "Content-Type": "multipart/form-data"
        }
    });
}

export async function updateVacation(updatedVacation: Partial<VacationModel>, id: number) {
    try {
        const response = await axios.put(`http://localhost:4000/api/v1/vacations/${id}`, updatedVacation, getAuthHeaders());
        return response.data;
    } catch (error) {
        console.error("Error updating vacation:", error);
        throw new Error("Failed to update vacation.");
    }
}

export async function uploadVacationImage(vacationId: number, image: File): Promise<void> {
    if (!vacationId) throw new Error("Vacation ID is required to upload image");

    const url = `http://localhost:4000/api/v1/image/${vacationId}`;
    const formData = new FormData();
    formData.append('image', image);

    try {
        await axios.post(url, formData, getAuthHeaders());
    } catch (error) {
        console.error("Error uploading vacation image:", error);
        throw error;
    }
}

export async function getVacationImages(vid: number) {
    if (!vid) {
        throw new Error("Vacation ID is required to fetch images");
    }
    try {
        const res = await axios.get(`http://localhost:4000/api/v1/images/${vid}`, getAuthHeaders());
        return res.data;
    } catch (error) {
        console.error("Error fetching vacation images:", error);
        throw error;
    }
}

export async function deleteV(id: number): Promise<void> {
    try {
        await axios.delete(`http://localhost:4000/api/v1/vacations/${id}`, getAuthHeaders());
    } catch (error) {
        console.error("Error deleting vacation:", error);
        throw new Error("Failed to delete vacation.");
    }
}

export async function downloadVacationReportCSV(): Promise<Blob> {
    try {
        const response = await axios.get("http://localhost:4000/api/v1/vacations/report/csv", {
            ...getAuthHeaders(),
            responseType: "blob"
        });
        return response.data;
    } catch (error) {
        console.error("Error downloading CSV:", error);
        throw error;
    }
}