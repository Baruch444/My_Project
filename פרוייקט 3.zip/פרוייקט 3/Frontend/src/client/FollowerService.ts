import axios from "axios";
import FollowersModel from "../models/FollowersModel";
import { getAuthHeaders } from "./vacationApi";

class FollowerService {
    public async addLike(follower: FollowersModel): Promise<void> {
        const response = await axios.post("http://localhost:4000/api/v1/followers", follower, getAuthHeaders());
        return response.data; 
    }
    
    public async removeLike(follower: { userId: number; vacationId: number }): Promise<void> {
        const response = await axios.delete("http://localhost:4000/api/v1/followers", { 
            data: follower, 
            ...getAuthHeaders() 
        });
        return response.data; 
    }
    
    public async getVacationLikes(): Promise<any[]> {
        const response = await axios.get("http://localhost:4000/api/v1/followers", getAuthHeaders());
        return response.data;
    }
    
    public async getVacationLikesCount(vacationId: number): Promise<number> {
        const response = await axios.get("http://localhost:4000/api/v1/follower-count", getAuthHeaders());
        const vacation = response.data.find((item: any) => item.vacation_id === vacationId);
        return vacation ? vacation.like_count : 0;
    }
    
    public async getFollowersByUserId(userId: number): Promise<FollowersModel[]> {
        const response = await axios.get(`http://localhost:4000/api/v1/followers/${userId}`, getAuthHeaders());
        return response.data; 
    }
    
    public async isUserFollowing(userId: number, vacationId: number): Promise<boolean> {
        const res = await axios.get("http://localhost:4000/api/v1/follower", {
            params: { userId, vacationId },
            ...getAuthHeaders()
        });
        return res.data.isFollowing;
    }
    
    public async getLikedVacations(userId: number): Promise<any[]> {
        const response = await axios.get(`http://localhost:4000/api/v1/followers-likedv/${userId}`, getAuthHeaders());
        return response.data;  
    }
}

const followerService = new FollowerService();
export default followerService;
