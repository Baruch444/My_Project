class Config {
    public vacationsUrl = "http://localhost:4000/api/v1/vacations/";
    public loginUrl = "http://localhost:4000/api/v1/login/";
    public registerUrl = "http://localhost:4000/api/v1/register/";
    public imgUrl = "http://localhost:4000/api/v1/image/";
}
const appConfig = new Config();
export default appConfig;