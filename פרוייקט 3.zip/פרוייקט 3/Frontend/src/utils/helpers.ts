import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { store } from "../redux/store";
import { format } from 'date-fns-tz';

export function parseJwt(token: string) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
}

export function convertToTimeZone(date: string, timeZone: string = 'Asia/Jerusalem'): string {
    const formattedDate = format(new Date(date), 'yyyy-MM-dd HH:mm:ss', { timeZone });
    return formattedDate;
}

export function useVerifyLoggedIn() {
    const navigate = useNavigate();
    useEffect(() => {
        const token = store.getState().auth.token;
        if (!token) {
            navigate("/login");
            return;
        }
    }, []);
}
export function useVerifyAdmin() {
    const navigate = useNavigate();
    useEffect(() => {
        const user = store.getState().auth.user;
        if (!user.isAdmin) {
            navigate("/vacations");
            return;
        }
    }, []);
}
