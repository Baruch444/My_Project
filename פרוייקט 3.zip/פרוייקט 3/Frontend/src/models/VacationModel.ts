export class VacationModel {
    public id: number;
    public destination: string;
    public description: string;
    public start_date: string;
    public end_date: string;
    public price: number;
    public imageUrls: string[];
    public isFollowed: boolean; 

    public static destinationValidation = {
        required: { value: true, message: "Destination is required" },
        minLength: { value: 2, message: "Destination must be more than 2 characters" },
        maxLength: { value: 50, message: "Destination must be less than 50 characters" }
    }
    public static descriptionValidation = {
        required: { value: true, message: "Description is required" },
        minLength: { value: 10, message: "Description must be more than 10 characters" },
        maxLength: { value: 2000, message: "Description must be less than 2000 characters" }
    }
    public static checkInValidation = {
    required: { value: true, message: "Check-in is required" },
    validate: {
        isValidDateTime: (value: string) => {
            if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) {
                return "Check-in must include both date and time.";
            }
            const selectedDate = new Date(value);
            const today = new Date();
            if (selectedDate <= today) {
                return "Check-in date must be in the future.";
            }
            return true;
        }
    }
};

public static checkOutValidation = {
    required: { value: true, message: "Check-out is required" },
    validate: {
        isValidDateTime: (value: string, formValues: any) => {
            if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) {
                return "Check-out must include both date and time.";
            }
            const selectedDate = new Date(value);
            const checkInDate = new Date(formValues.start_date);
            if (selectedDate <= checkInDate) {
                return "Check-out can't be before or on the same day as check-in date!";
            }
            const today = new Date();
            if (selectedDate <= today) {
                return "Check-out date must be in the future.";
            }
            return true;
        }
    }
};
    public static priceValidation = {
        required: { value: true, message: "Price is required" },
        min: { value: 1, message: "Price must be between 1 and 10000" },
        max: { value: 10000, message: "Price must be lower than 10000" }
    }
}