class FollowersModel {
    public constructor(public userId: number, public vacationId: number){}
}

export default FollowersModel;
