import { Route, Routes } from "react-router-dom";
import "./Routing.css";
import PageNotFound from "../PageNotFound/PageNotFound";
import Login from "../../authArea/Login/Login";
import Register from "../../authArea/Register/Register";
import Vacations from "../../vacationArea/Vacations/Vacations";
import AddVacation from "../../vacationArea/AddVacation/AddVacation";
import EditVacation from "../../vacationArea/EditVacation/EditVacation";
import AuthMenu from "../../authArea/AuthMenu/AuthMenu";
import VacationReport from "../../vacationArea/VacationReport/VacationReport";
import UserModel from "../../../models/UserModel";

interface RoutingProps {
    user: UserModel | null;
}

function Routing({ user }: RoutingProps): JSX.Element {

    return (
        <div className="Routing">
			<Routes>
                <Route path="/" element={<Login />} />
                <Route path="/*" element={<PageNotFound />} />
                <Route path="/auth-menu" element={<AuthMenu />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/vacations" element={<Vacations user={user ? { id: user.id, name: `${user.firstName} ${user.lastName}`, isAdnmin: user.isAdmin } : null} />} />
                <Route path="/add-vacation" element={<AddVacation />} />
                <Route path="/edit-vacation/:id" element={<EditVacation />} />
                <Route path="/report" element={<VacationReport />} />
            </Routes>
        </div>
    );
}

export default Routing;
