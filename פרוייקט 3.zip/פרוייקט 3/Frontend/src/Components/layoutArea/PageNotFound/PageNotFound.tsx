import "./PageNotFound.css";

function PageNotFound(): JSX.Element {
    return (
        <div className="PageNotFound">
			page not found
        </div>
    );
}

export default PageNotFound;
