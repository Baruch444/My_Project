import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Header from "../Header/Header";
import Routing from "../Routing/Routing";
import "./Layout.css";
import followerService from "../../../client/FollowerService";
import { RootState } from "../../../redux/store";
import { setFollowers } from "../../../redux/slices/followersSlice";
import { setUser } from "../../../redux/slices/authSlice";

function Layout(): JSX.Element {
    const dispatch = useDispatch();
    const user = useSelector((state: RootState) => state.auth.user); 
    
    useEffect(() => {
        const loadUserFromStorage = () => {
            const userData = localStorage.getItem("user");
            if (userData) {
                const parsedUser = JSON.parse(userData);
                dispatch(setUser(parsedUser));
            }
        };
        loadUserFromStorage();
    
        const fetchFollowers = async () => {
            if (user) {
                try {
                    const followers = await followerService.getFollowersByUserId(user.id);
                    dispatch(setFollowers(followers));
                } catch (error) {
                    console.error("Error fetching followers:", error);
                }
            }
        };
        
        fetchFollowers();
    }, []);
    
    return (
        <div className="Layout">
            <header>
                <Header />
            </header>
            <main>
                <div className="main-animation"></div>
                <Routing user={user} />
            </main>
        </div>
    );
}

export default Layout;
