import { NavLink } from "react-router-dom";
import "./Header.css";
import AuthMenu from "../../authArea/AuthMenu/AuthMenu";
import { useSelector } from "react-redux";
import { RootState } from "../../../redux/store";

function Header(): JSX.Element {

    const user = useSelector((state: RootState) => state.auth.user);
    

    return (
        <div className="Header">
            <div className="Header-content">
                <div className="logo">
                    <h1>Vacations</h1>
                </div>
                <div className="nav-links">
                    {user && user.isAdmin && (
                        <>
                            <NavLink to={"/add-vacation"} className="nav-link">Add Vacation</NavLink>
                            <NavLink to={"/report"} className="nav-link">Report</NavLink>
                            <NavLink to={"/vacations"} className="nav-link">Vacations</NavLink>
                        </>
                    )}
                </div>
                <div className="auth-menu">
                    <AuthMenu />
                </div>
            </div>
        </div>
    );
}


export default Header;
