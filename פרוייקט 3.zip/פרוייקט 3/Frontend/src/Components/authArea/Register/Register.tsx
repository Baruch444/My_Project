import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import authService from "../../../client/AuthServices";
import UserModel from "../../../models/UserModel";
import { parseJwt } from "../../../utils/helpers";
import { Container, Form, Button } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import { useEffect } from "react";
import { store } from "../../../redux/store";

interface RegisterFormModel {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  isAdmin: boolean;
}

const Register: React.FC = () => {
    const { register, handleSubmit, formState: { errors }, setError } = useForm<RegisterFormModel>();
    const navigate = useNavigate();

    useEffect(() => {
        const token = store.getState().auth.token;
        if (token) {
            navigate("/vacations");
            return;
        }
    },[]);

    const handleRegister = async (data: RegisterFormModel) => {
        try {
            const isAvailable = await authService.checkEmailAvailability(data.email);
        if (!isAvailable) {
            setError("email", { type: "manual", message: "plz provide another email, this email has already taken" });
            return;
        }
        const user: UserModel = {
            firstName: data.firstName,
            lastName: data.lastName,
            email: data.email,
            password: data.password,
            isAdmin: data.isAdmin,
        };
        const token = await authService.register(user);
        const parsedToken = parseJwt(token);
        if (parsedToken && parsedToken.userWithoutPassword) {
            localStorage.setItem("user", JSON.stringify(parsedToken.userWithoutPassword));
            alert(`Welcome, ${parsedToken.userWithoutPassword.firstName}`);
            navigate("/vacations");
        } else {
            throw new Error("Failed to register user.");
        }} catch (error) {
            console.error("Registration failed:", error);
            alert("Registration failed. Please try again.");
        }
    };

  return (
      <Container className="d-flex justify-content-center align-items-center mt-5" style={{ minHeight: '100%' }}>
          <div className="w-100" style={{ maxWidth: '400px' }}>
              <h2 className="text-center mb-4">Register</h2>
              <Form onSubmit={handleSubmit(handleRegister)} className="shadow p-4 rounded bg-light">
                  <Form.Group controlId="formFirstName" className="mb-3">
                      <Form.Label>First Name</Form.Label>
                      <Form.Control 
                          type="text" 
                          placeholder="Enter your first name"
                          {...register('firstName', { required: "First name is required" })} 
                          isInvalid={!!errors.firstName} 
                      />
                      {errors.firstName && <Form.Control.Feedback type="invalid">{errors.firstName.message}</Form.Control.Feedback>}
                  </Form.Group>

                  <Form.Group controlId="formLastName" className="mb-3">
                      <Form.Label>Last Name</Form.Label>
                      <Form.Control 
                          type="text" 
                          placeholder="Enter your last name"
                          {...register('lastName', { required: "Last name is required" })} 
                          isInvalid={!!errors.lastName} 
                      />
                      {errors.lastName && <Form.Control.Feedback type="invalid">{errors.lastName.message}</Form.Control.Feedback>}
                  </Form.Group>

                  <Form.Group controlId="formEmail" className="mb-3">
                      <Form.Label>Email</Form.Label>
                      <Form.Control 
                          type="email" 
                          placeholder="Enter your email"
                          autoComplete="username"
                          {...register('email', UserModel.emailValidation)} 
                          isInvalid={!!errors.email} 
                      />
                      {errors.email && <Form.Control.Feedback type="invalid">{errors.email.message}</Form.Control.Feedback>}
                  </Form.Group>

                  <Form.Group controlId="formPassword" className="mb-4">
                      <Form.Label>Password</Form.Label>
                      <Form.Control 
                          type="password" 
                          placeholder="Password"
                          autoComplete="current-password"
                          {...register('password', UserModel.passwordValidation)} 
                          isInvalid={!!errors.password}
                      />
                      {errors.password && <Form.Control.Feedback type="invalid">{errors.password.message}</Form.Control.Feedback>}
                  </Form.Group>

                  <Form.Group controlId="formIsAdmin" className="mb-4">
                      <Form.Check 
                          type="checkbox"
                          label="Register as admin"
                          {...register('isAdmin')}
                      />
                  </Form.Group>

                  <Button variant="primary" type="submit" className="w-100">Register</Button>
                  <p className="mt-3 text-center">
                    Already have an account? 
                    <br />
                    <NavLink to={"/login"}>Login here</NavLink>.
                  </p>
              </Form>
          </div>
      </Container>
  );
};

export default Register;
