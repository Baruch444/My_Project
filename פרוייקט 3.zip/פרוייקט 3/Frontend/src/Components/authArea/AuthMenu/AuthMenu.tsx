import { useEffect } from "react";
import { useSelector } from "react-redux";
import { RootState, store } from "../../../redux/store";
import authService from "../../../client/AuthServices";
import { useNavigate, NavLink } from "react-router-dom";
import "./AuthMenu.css";
import { login } from "../../../redux/slices/authSlice";

function AuthMenu(): JSX.Element {
    const user = useSelector((state: RootState) => state.auth.user);
    const navigate = useNavigate();
    
    useEffect(() => {
        if (!user) {
            const token = localStorage.getItem("token");
            if (token) {
                authService.getUserFromToken(token);
                store.dispatch(login(token));
            }
        }
    }, []);

    const logoutUser = () => {
        authService.logout();
        navigate("/login");
        alert("We will miss you...");
    };

    return (
        <div className="AuthMenu">
            {user ? (
                <div className="user-info">
                    <span className="welcome-message">Hello, {user.firstName} {user.lastName}</span>
                    <button onClick={logoutUser} className="logoutB">Logout</button>
                </div>
            ) : (
                <div className="guest-info">
                    <span className="guest-message">Hello Guest</span> 
                    <div className="auth-links">
                        <NavLink to="/login" className="auth-link">Login</NavLink> 
                        <NavLink to="/register" className="auth-link">Register</NavLink>
                    </div>
                </div>
            )}
        </div>
    );
}

export default AuthMenu;
