import React, { useEffect, useState } from 'react';
import authService from '../../../client/AuthServices';
import { useForm } from 'react-hook-form';
import { NavLink, useNavigate } from 'react-router-dom';
import { Container, Form, Button } from "react-bootstrap"; 
import { store } from '../../../redux/store';
import UserModel from '../../../models/UserModel';

interface LoginFormModel {
  email: string;
  password: string;
}

const Login: React.FC = () => {
    const { register, handleSubmit, formState: { errors }, setError } = useForm<LoginFormModel>();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const token = store.getState().auth.token;
        if (token) {
            navigate("/vacations");
            return;
        }
    }, []);

    const handleLogin = async (data: LoginFormModel) => {
        setLoading(true);
        try {
            const user = await authService.login(data);
            if (user) {
                localStorage.setItem("user", JSON.stringify(user));
                navigate("/vacations");
            } else {
                setError('password', {
                    type: 'manual',
                    message: 'Login failed. Invalid token received.',
                });
            }
        } catch (error) {
            console.error("Login failed:", error);
            setError('password', {
                type: 'manual',
                message: 'Login failed. Please check your email and password.',
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <Container className="d-flex justify-content-center align-items-center mt-5" style={{ minHeight: '100%' }}>
            <div className="w-100" style={{ maxWidth: '400px' }}>
                <h2 className="text-center mb-4">Login</h2>
                <Form onSubmit={handleSubmit(handleLogin)} className="shadow p-4 rounded bg-light">
                    <Form.Group controlId="formEmail" className="mb-3">
                        <Form.Label>Email</Form.Label>
                        <Form.Control
                            type="email"
                            placeholder="Enter your email"
                            autoComplete="username"
                            {...register('email', UserModel.emailValidation)}
                            isInvalid={!!errors.email}
                        />
                        {errors.email && <Form.Control.Feedback type="invalid">{errors.email.message}</Form.Control.Feedback>}
                    </Form.Group>

                    <Form.Group controlId="formPassword" className="mb-4">
                        <Form.Label>Password</Form.Label>
                        <Form.Control
                            type="password"
                            placeholder="Password"
                            autoComplete="current-password"
                            {...register('password', UserModel.passwordValidation)}
                            isInvalid={!!errors.password}
                        />
                        {errors.password && <Form.Control.Feedback type="invalid">{errors.password.message}</Form.Control.Feedback>}
                    </Form.Group>

                    <Button variant="primary" type="submit" disabled={loading} className="w-100">
                        {loading ? 'Logging in...' : 'Login'}
                    </Button>
                    <div className="mt-3 text-center">
                        Don't have an account? <NavLink to={"/register"}>Register here</NavLink>.
                    </div>
                </Form>
            </div>
        </Container>
    );
};

export default Login;
