import { useEffect, useState } from "react";
import { deleteV, getAllVacationsPaginated } from "../../../client/vacationApi";
import { VacationModel } from "../../../models/VacationModel";
import VacationCard from "../VacationCard/VacationCard";
import "./Vacations.css";
import { useDispatch } from "react-redux";
import followerService from "../../../client/FollowerService";
import { setFollowers } from "../../../redux/slices/followersSlice";
import { useNavigate } from "react-router-dom";
import InfiniteScroll from "react-infinite-scroller";
import { useVerifyLoggedIn } from "../../../utils/helpers";
import { Modal, Button } from "react-bootstrap";
import Loader from "../../layoutArea/Loader/Loader";

interface VacationsProps {
    user: { id: number; name: string; isAdnmin?: boolean } | null;
}

function Vacations({ user }: VacationsProps): JSX.Element {
    const [vacations, setVacations] = useState<VacationModel[]>([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState<number>(1);
    const [hasMore, setHasMore] = useState(true);
    const [favoriteOnly, setFavoriteOnly] = useState<boolean>(false);
    const [activeOnly, setActiveOnly] = useState<boolean>(false);
    const [notStartedOnly, setNotStartedOnly] = useState<boolean>(false);
    const [likedVacationIds, setLikedVacationIds] = useState<number[]>([]);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [vacationToDelete, setVacationToDelete] = useState<number | null>(null);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    
    useVerifyLoggedIn();

    const updateLikedVacationIds = (vacationId: number) => {
        setLikedVacationIds((prevLikedIds) => {
            if (prevLikedIds.includes(vacationId)) {
                return prevLikedIds.filter(id => id !== vacationId);
            } else {
                return [...prevLikedIds, vacationId]; 
            }
        });
    };

    useEffect(() => {
        const fetchVacationsAndFollowers = async () => {
            if (!user) {
                setLoading(false);
                navigate('/login'); 
                return;
            }
            try {
                const followersData = await followerService.getFollowersByUserId(user.id);
                const likedVacations = followersData.map((follower: any) => follower.vacation_id);
                setLikedVacationIds(likedVacations);
                dispatch(setFollowers(followersData));
            } catch (error) {
                console.error("Error fetching vacations or followers:", error);
            } finally {
                setLoading(false);
            }
        };
        if (user) {
            fetchVacationsAndFollowers();
        }
    }, [user, dispatch]);

    useEffect(() => {
        if (favoriteOnly) {
            const fetchLikedVacations = async () => {
                if (user) {
                    try {
                        const followersData = await followerService.getFollowersByUserId(user.id);
                        const likedVacations = followersData.map((follower: any) => follower.vacation_id);
                        setLikedVacationIds(likedVacations);
                    } catch (error) {
                        console.error("Error fetching liked vacations:", error);
                    }
                }
            };
            fetchLikedVacations();
        }
    }, [favoriteOnly, user]);

    const loadMoreVacations = async () => {
        try {
            const newVacations = await getAllVacationsPaginated(page);
            if (newVacations.length === 0) {
                setHasMore(false); 
            } else {
                setVacations(prevVacations => {
                    const combinedVacations = [...prevVacations, ...newVacations];
                    const uniqueVacations = combinedVacations.filter(
                        (vacation, index, self) =>
                            index === self.findIndex((v) => v.id === vacation.id)
                    );
                    return uniqueVacations;
                });
                setPage(prevPage => prevPage + 1);
            }
        } catch (error) {
            console.error("Error fetching more vacations:", error);
            setHasMore(false); 
        }
    };

    const confirmDeleteVacation = (id: number) => {
        setVacationToDelete(id);
        setShowDeleteModal(true);
    };

    const handleDeleteConfirmed = async () => {
        if (vacationToDelete !== null) {
            try {
                await deleteV(vacationToDelete);
                setVacations(prevVacations => prevVacations.filter(v => v.id !== vacationToDelete));
                alert("Vacation deleted successfully!");
            } catch (error) {
                console.error("Error deleting vacation:", error);
                alert("Failed to delete vacation.");
            } finally {
                setShowDeleteModal(false);
                setVacationToDelete(null);
            }
        }
    };

    const handleDeleteCancelled = () => {
        setShowDeleteModal(false);
        setVacationToDelete(null);
    };

    const handleActiveOnlyChange = () => {
        setActiveOnly(!activeOnly);
        if (!activeOnly && notStartedOnly) {
            setNotStartedOnly(false); 
        }
    };

    const handleNotStartedOnlyChange = () => {
        setNotStartedOnly(!notStartedOnly);
        if (!notStartedOnly && activeOnly) {
            setActiveOnly(false); 
        }
    };
    
    const toggleFavoriteOnly = () => {
        setFavoriteOnly(prevState => !prevState);
    };

    const filteredVacations = vacations.filter((vacation) => {
        if (favoriteOnly && !likedVacationIds.includes(vacation.id)) return false;
        if (activeOnly && (new Date(vacation.start_date) > new Date() || new Date(vacation.end_date) < new Date())) {
            return false;
        }
        if (notStartedOnly && new Date(vacation.start_date) <= new Date()) return false;
        return true;
    });
    const sortedVacations = [...filteredVacations].sort((a, b) => new Date(a.start_date).getTime() - new Date(b.start_date).getTime());

    if (loading) {
        return <Loader />;
    }

    return (
        <div className="Vacations">
            <div className="filters">
                { !user.isAdnmin && (  
                    <label>
                        <input
                            type="checkbox"
                            checked={favoriteOnly}
                            onChange={toggleFavoriteOnly}
                        />
                        <span></span> Favorites
                    </label>
                )}
                <label>
                    <input
                        type="checkbox"
                        checked={activeOnly}
                        onChange={handleActiveOnlyChange}
                    />
                    <span></span> Active Vacations
                </label>
                <label>
                    <input
                        type="checkbox"
                        checked={notStartedOnly}
                        onChange={handleNotStartedOnlyChange}
                    />
                    <span></span> Not Started Vacations
                </label>
            </div>

            <InfiniteScroll 
                pageStart={1}
                loadMore={loadMoreVacations}
                hasMore={hasMore}
                loader={<div key={0}>Loading more vacations...</div>}
            >
                <div className="vacations-grid">
                    {user && sortedVacations.map((vacation) => (
                        <VacationCard
                            key={vacation.id}
                            v={vacation}
                            handleDelete={confirmDeleteVacation}
                            updateLikedVacationIds={updateLikedVacationIds}
                        />
                    ))}
                </div>
            </InfiniteScroll>

            <Modal show={showDeleteModal} onHide={handleDeleteCancelled}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Delete</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to delete this vacation?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleDeleteCancelled}>
                        Cancel
                    </Button>
                    <Button variant="danger" onClick={handleDeleteConfirmed}>
                        Delete
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}

export default Vacations;
