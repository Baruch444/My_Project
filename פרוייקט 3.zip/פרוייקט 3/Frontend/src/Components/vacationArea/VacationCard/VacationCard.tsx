import { useNavigate } from "react-router-dom";
import { VacationModel } from "../../../models/VacationModel";
import VacationImage from "../VacationImage/VacationImage";
import { Card, Button } from 'react-bootstrap';
import { useDispatch, useSelector } from "react-redux"; 
import { addFollower, removeFollower } from "../../../redux/slices/followersSlice"; 
import "./VacationCard.css";
import followerService from "../../../client/FollowerService";
import { RootState } from "../../../redux/store";
import { useState, useEffect } from "react";
import { convertToTimeZone } from "../../../utils/helpers";

interface VacationCardProps {
    v: VacationModel;
    handleDelete: (vid: number) => void;
    updateLikedVacationIds: (vacationId: number, action: 'add' | 'remove') => void; 
}

function VacationCard({ v, handleDelete, updateLikedVacationIds }: VacationCardProps): JSX.Element {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const user = useSelector((state: RootState) => state.auth.user);
    const [isLiked, setIsLiked] = useState<boolean>(false); 
    const [likeCount, setLikeCount] = useState<number>(0);

    useEffect(() => {
        if (user) {
            followerService.isUserFollowing(user.id, v.id)
                .then((isFollowing) => {
                    setIsLiked(isFollowing)
                })
                .catch((error) => console.error("Error checking like status:", error));
        }

        followerService.getVacationLikesCount(v.id)
        .then((count) => setLikeCount(count))
        .catch((error) => console.error("Error fetching like count:", error));
    }, [user, v.id]);

    const handleEdit = () => {
        navigate(`/edit-vacation/${v.id}`); 
    };

    const handleLike = () => {
        if (!user) {
            return;
        }
        const likeData = { userId: user.id, vacationId: v.id };
    
        if (isLiked) {
            followerService.removeLike(likeData)
                .then(() => {
                    dispatch(removeFollower(likeData)); 
                    setIsLiked(false); 
                    setLikeCount((prev) => prev - 1);
                    updateLikedVacationIds(v.id, 'remove'); 
                })
                .catch((error) => console.error("Error removing like:", error));
        } else {
            followerService.addLike(likeData)
                .then(() => {
                    dispatch(addFollower(likeData));
                    setIsLiked(true); 
                    setLikeCount((prev) => prev + 1);
                    updateLikedVacationIds(v.id, 'add');
                })
                .catch((error) => console.error("Error adding like:", error));
        }
    };

    return (
        <Card className="VacationCard">
            <div className="image-container">
                <VacationImage vid={v.id} />
                {user?.isAdmin && (
                    <div className="button-container">
                        <Button variant="primary" onClick={handleEdit}>Edit</Button>
                        <Button variant="danger" onClick={() => handleDelete(v.id)}>Delete</Button>
                    </div>
                )}
                {!user?.isAdmin && (
                    <div className="button-like">
                        <Button 
                            variant={isLiked ? "danger" : "success"} 
                            onClick={handleLike}
                        >
                            {isLiked ? `Remove Like` : `Like`} ({likeCount}) 
                        </Button>
                    </div>
                )}
            </div>
            <Card.Body>
                <Card.Title className="destination">{v.destination}</Card.Title>
                <Card.Text className="v-card">
                    <span className="datef"><strong>From:</strong> {convertToTimeZone(v.start_date)} <br /> <strong>To:</strong> {convertToTimeZone(v.end_date)}</span>
                    <span className="description-scroll">{v.description}</span><br />
                    <span className="prc"><strong>Price:</strong> ${v.price}</span> 
                </Card.Text>
            </Card.Body>
        </Card>
    );
}

export default VacationCard;
