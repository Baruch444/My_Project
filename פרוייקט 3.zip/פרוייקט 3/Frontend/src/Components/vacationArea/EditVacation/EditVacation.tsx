import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import { VacationModel } from "../../../models/VacationModel";
import { getVacationById, updateVacation, uploadVacationImage, getVacationImages } from "../../../client/vacationApi";
import { Container, Form, Button } from "react-bootstrap";
import { convertToTimeZone, useVerifyAdmin } from "../../../utils/helpers";
import "./EditVacation.css";

function EditVacation(): JSX.Element {
    const { id } = useParams<{ id: string }>(); 
    const { register, handleSubmit, setValue, formState: { errors } } = useForm<VacationModel>();
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [currentImage, setCurrentImage] = useState<string | null>(null); 
    const navigate = useNavigate();

    useVerifyAdmin();

    useEffect(() => {
        const fetchVacation = async () => {
            if (id) {
                try {
                    const vacation = await getVacationById(+id);
                    setValue("destination", vacation.destination);
                    setValue("description", vacation.description);
                    setValue("start_date", convertToTimeZone(vacation.start_date));
                    setValue("end_date", convertToTimeZone(vacation.end_date)); 
                    setValue("price", vacation.price);

                    const vacationImages = await getVacationImages(+id);
                    if (vacationImages.length > 0) {
                        setCurrentImage(vacationImages[0]); 
                    }
                } catch (error) {
                    console.error("Error fetching vacation:", error);
                }
            }
        };

        fetchVacation();
    }, [id, setValue]);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files ? e.target.files[0] : null;
        if (file) {
            setImageFile(file);
            setCurrentImage(URL.createObjectURL(file)); 
        }
    };

    const onSubmit = async (data: VacationModel) => {
        try {
            await updateVacation(data, +id);
            if (imageFile) {
                await uploadVacationImage(+id, imageFile);
            }
            navigate("/vacations"); 
        } catch (error) {
            console.error("Error updating vacation:", error);
        }
    };

    return (
        <Container className="EditVacation">
            <h2>Edit Vacation</h2>
            
            <Form onSubmit={handleSubmit(onSubmit)}>
                <Form.Group className="mb-4">
                    <Form.Label>Destination</Form.Label>
                    <Form.Control 
                        placeholder="Enter vacation destination" 
                        {...register("destination", VacationModel.destinationValidation)} 
                        isInvalid={!!errors.destination}
                    />
                    {errors.destination && <Form.Text className="text-danger">{errors.destination.message}</Form.Text>}
                </Form.Group>
                
                <Form.Group className="mb-4">
                    <Form.Label>Description</Form.Label>
                    <Form.Control 
                        as="textarea" 
                        placeholder="Enter a detailed description of the vacation" 
                        {...register("description", VacationModel.descriptionValidation)} 
                        isInvalid={!!errors.description}
                    />
                    {errors.description && <Form.Text className="text-danger">{errors.description.message}</Form.Text>}
                </Form.Group>
                
                <Form.Group className="mb-4">
                    <Form.Label>Start Date</Form.Label>
                    <Form.Control 
                        type="dateTime-local" 
                        {...register("start_date", VacationModel.checkInValidation)} 
                        isInvalid={!!errors.start_date}
                    />
                    {errors.start_date && <Form.Text className="text-danger">{errors.start_date.message}</Form.Text>}
                </Form.Group>
                
                <Form.Group className="mb-4">
                    <Form.Label>End Date</Form.Label>
                    <Form.Control 
                        type="dateTime-local" 
                        {...register("end_date", VacationModel.checkOutValidation)} 
                        isInvalid={!!errors.end_date}
                    />
                    {errors.end_date && <Form.Text className="text-danger">{errors.end_date.message}</Form.Text>}
                </Form.Group>
                
                <Form.Group className="mb-4">
                    <Form.Label>Price</Form.Label>
                    <Form.Control 
                        type="number" 
                        placeholder="Enter price" 
                        {...register("price", VacationModel.priceValidation)} 
                        isInvalid={!!errors.price}
                    />
                    {errors.price && <Form.Text className="text-danger">{errors.price.message}</Form.Text>}
                </Form.Group>

                {currentImage && (
                    <Form.Group className="mb-4">
                        <Form.Label>Current Image</Form.Label>
                        <div className="imgEdit">
                            <img 
                                src={currentImage.startsWith("blob") ? currentImage : `http://localhost:4000/api/v1/image/${currentImage}`} 
                                alt="Current vacation" 
                                className="img-thumbnail"
                            />
                        </div>
                    </Form.Group>
                )}

                <Form.Group className="mb-4">
                    <Form.Label>Image</Form.Label>
                    <Form.Control 
                        type="file" 
                        accept="image/*" 
                        onChange={handleImageChange} 
                    />
                </Form.Group>

                <Button type="submit" variant="primary">
                    Update Vacation
                </Button>
            </Form>
        </Container>
    );
}

export default EditVacation;
