import { ChangeEvent, FormEvent, useState } from "react";
import { uploadVacationImage } from "../../../client/vacationApi";
import { Modal } from "react-bootstrap";


type AddImageProps = {
    vid: number;
    showModal: boolean;
    setShowModal: React.Dispatch<React.SetStateAction<boolean>>;
    handleDeleteVacation?: (id: number) => void;
}

const AddImage = ({ vid, showModal, setShowModal, handleDeleteVacation }: AddImageProps) => {
    const [image, setImage] = useState<File | undefined>();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [hasUploaded, setHasUploaded] = useState(false);

    const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        if (!image) {
            alert("You must choose an image.");
            return;
        }

        setLoading(true);
        setError(null);

        try {
            await uploadVacationImage(vid, image);
            alert("Image added successfully!");
            setHasUploaded(true);
            setShowModal(false);
        } catch (err) {
            console.error("Error uploading image:", err);
            setError("There was an error uploading the image. Please try again.");
        } finally {
            setLoading(false);
        }

    };

    const handleClose = () => {
        setShowModal(false);
        if (!hasUploaded) {
            handleDeleteVacation(vid);
        }
    };

    return (
        <>
        <Modal show={showModal} onHide={handleClose} backdrop="static">
            <Modal.Header >
                <Modal.Title>Add Image for Vacation ID: {vid}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <form onSubmit={handleSubmit}>
                    {error && <p style={{ color: "red" }}>{error}</p>}
                    <div className="mb-3">
                        <input
                            required
                            type="file"
                            className="form-control"
                            onChange={(e: ChangeEvent<HTMLInputElement>) => {
                                if (e.target.files) setImage(e.target.files[0]);
                            }}
                            />
                    </div>
                    <button type="submit" className="btn btn-primary" disabled={loading}>
                        {loading ? "Uploading..." : "Finish adding vacation!"}
                    </button>
                </form>
            </Modal.Body>
        </Modal>
        </>
    );
};

export default AddImage;

