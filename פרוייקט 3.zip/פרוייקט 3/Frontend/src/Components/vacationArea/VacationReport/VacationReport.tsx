import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import followerService from '../../../client/FollowerService';
import { downloadVacationReportCSV } from '../../../client/vacationApi';
import * as XLSX from 'xlsx';
import "./VacationReport.css"
import { useVerifyLoggedIn } from '../../../utils/helpers';

interface VacationLike {
    vacation_id: number;
    destination: string;
    like_count: number;
}

const VacationReport: React.FC = () => { 
    const [vacationLikes, setVacationLikes] = useState<VacationLike[]>([]);
    useVerifyLoggedIn();
    useEffect(() => {
        const fetchVacationLikes = async () => {
            const data = await followerService.getVacationLikes();
            const filteredData = data.filter((vacation: VacationLike) => vacation.like_count > 0);
            setVacationLikes(filteredData);
        };   
        fetchVacationLikes();
    }, []);

    const handleDownloadCSV = async () => {
        try {
            const blob = await downloadVacationReportCSV();
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = "vacation_report.csv";
            link.click();
            window.URL.revokeObjectURL(url);
        } catch (error) {
            console.error("Failed to download CSV:", error);
        }
    };

    const handleDownloadExcel = () => {
        const ws = XLSX.utils.json_to_sheet(vacationLikes); 
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Vacation Report");
        XLSX.writeFile(wb, "vacations_report.xlsx"); 
    };

    return (
        <div>
            <div className='cha' style={{border: "1px solid", margin: "5px", padding: "5px"}}>
                <h2>Vacation Report</h2>
                <BarChart width={800} height={350} data={vacationLikes}>
                    <XAxis  height={110}
                        dataKey="destination" 
                        angle={-45} 
                        textAnchor="end"
                        />
                    <YAxis />
                    <Tooltip />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Bar dataKey="like_count" fill="#8884d8" />
                </BarChart>
            </div>
            <div className='btdown'>
                <button className='btnCsv' onClick={handleDownloadCSV}>Download CSV</button>
                <button className='btnEx' onClick={handleDownloadExcel}>Download Excel</button>
            </div>
        </div>
    );
};

export default VacationReport;
