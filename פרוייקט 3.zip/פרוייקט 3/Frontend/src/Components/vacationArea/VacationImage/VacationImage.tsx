import "./VacationImage.css"
import { useState, useEffect } from "react";
import { getVacationImages } from "../../../client/vacationApi";

type Props = {
    vid: number;
}

const VacationImages = (props: Props) => {
    const [images, setImages] = useState<string[]>([])

    useEffect(()=>{
        getVacationImages(props.vid).then((images_)=>{
            setImages(images_);
        })
    }, [])

  return (
    <>
    <div >
        {images.map((im:string)=>{
            return <img key={im} className="v-img" src={`http://localhost:4000/api/v1/image/${im}`} alt='vacation-image'/>
        })}
    </div>
    </>
  )
}

export default VacationImages;