import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { VacationModel } from "../../../models/VacationModel";
import { addVacation, addVacationImage } from "../../../client/vacationApi";
import { useNavigate } from "react-router-dom";
import { Container, Form, Button, Alert } from "react-bootstrap";
import { useSelector } from "react-redux";
import { RootState } from "../../../redux/store";
import "./AddVacation.css"; 
import { useVerifyAdmin, useVerifyLoggedIn } from "../../../utils/helpers";

function AddVacation(): JSX.Element {
    const { register, handleSubmit, formState: { errors } } = useForm<VacationModel>();
    const [vacationId, setVacationId] = useState<number | null>(null); 
    const [imageFile, setImageFile] = useState<File | null>(null); 
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [imgError, setImgError] = useState<string | null>(null);
    const navigate = useNavigate();
    const user = useSelector((state: RootState) => state.auth.user);

    useVerifyLoggedIn();
    useVerifyAdmin();

    const onSubmit = async (data: VacationModel) => {
        if (!imageFile) {
            setImgError("Please provide an image!");
            return;
        }
        setImgError(null);
        try {
            const vacationId = await addVacation(data);
            setVacationId(vacationId);
            if (imageFile) {
                await addVacationImage(vacationId, imageFile);
            }
            navigate("/vacations");
        } catch (error) {
            console.error("Error adding vacation:", error);
        }
    };

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files ? e.target.files[0] : null;
        setImageFile(file);
        if (file) {
            setImagePreview(URL.createObjectURL(file));
        } else {
            setImagePreview(null);
        }
    };

    return (
        <Container className="AddVacation">
            <h2>Add New Vacation</h2>
            
            <Form onSubmit={handleSubmit(onSubmit)}>
                <Form.Group className="mb-4">
                    <Form.Label>Destination</Form.Label>
                    <Form.Control 
                        placeholder="Enter vacation destination" 
                        {...register("destination", VacationModel.destinationValidation)} 
                        isInvalid={!!errors.destination}
                    />
                    {errors.destination && <Form.Text className="text-danger">{errors.destination.message}</Form.Text>}
                </Form.Group>
                
                <Form.Group className="mb-4">
                    <Form.Label>Description</Form.Label>
                    <Form.Control 
                        as="textarea" 
                        placeholder="Enter a detailed description of the vacation" 
                        {...register("description", VacationModel.descriptionValidation)} 
                        isInvalid={!!errors.description}
                    />
                    {errors.description && <Form.Text className="text-danger">{errors.description.message}</Form.Text>}
                </Form.Group>
                
                <Form.Group className="mb-4">
                    <Form.Label>Start Date</Form.Label>
                    <Form.Control 
                        type="dateTime-local" 
                        {...register("start_date", VacationModel.checkInValidation)} 
                        isInvalid={!!errors.start_date}
                    />
                    {errors.start_date && <Form.Text className="text-danger">{errors.start_date.message}</Form.Text>}
                </Form.Group>
                
                <Form.Group className="mb-4">
                    <Form.Label>End Date</Form.Label>
                    <Form.Control 
                        type="dateTime-local" 
                        {...register("end_date", VacationModel.checkOutValidation)} 
                        isInvalid={!!errors.end_date}
                    />
                    {errors.end_date && <Form.Text className="text-danger">{errors.end_date.message}</Form.Text>}
                </Form.Group>
                
                <Form.Group className="mb-4">
                    <Form.Label>Price</Form.Label>
                    <Form.Control 
                        type="number" 
                        placeholder="Enter price" 
                        {...register("price", VacationModel.priceValidation)} 
                        isInvalid={!!errors.price}
                    />
                    {errors.price && <Form.Text className="text-danger">{errors.price.message}</Form.Text>}
                </Form.Group>
                
                <Form.Group className="mb-4">
                    <Form.Label>Image</Form.Label>
                    <Form.Control 
                        type="file" 
                        accept="image/*" 
                        onChange={handleImageChange} 
                        isInvalid={!!imgError}
                    />
                    {imgError && <Form.Text className="text-danger">{imgError}</Form.Text>}
                </Form.Group>

                {imagePreview && (
                    <div className="image-preview">
                        <img src={imagePreview} alt="Preview" className="img-fluid" />
                    </div>
                )}

                <Button type="submit" variant="primary">
                    Add Vacation
                </Button>
            </Form>
        </Container>
    );
}

export default AddVacation;
