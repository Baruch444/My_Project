import "./index.css";
import ReactDOM from 'react-dom/client';
import { Provider } from 'react-redux';
import { store } from './redux/store';
import Layout from './Components/layoutArea/Layout/Layout';
import { BrowserRouter } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.css";



const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  <Provider store={store}>
    <BrowserRouter>
      <Layout />
    </BrowserRouter>
  </Provider>
);

