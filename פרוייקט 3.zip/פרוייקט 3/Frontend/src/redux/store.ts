import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./slices/authSlice";
import vacationReducer from "./slices/VacationsSlice";
import followersReducer from "./slices/followersSlice";

export const store = configureStore({
    reducer: {
        auth: authReducer,
        vacations: vacationReducer,
        followers: followersReducer
    }
});

export type RootState = ReturnType<typeof store.getState>;