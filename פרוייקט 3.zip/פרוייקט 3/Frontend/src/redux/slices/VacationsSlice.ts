import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { VacationModel } from "../../models/VacationModel";

interface VacationState {
    vacationsList: VacationModel[];
}

const initialState: VacationState = {
    vacationsList: [],
}

const vacationsSlice = createSlice({
    name: "vacations", 
    initialState,      
    reducers: {        

        fetchVacations: (state, action: PayloadAction<VacationModel[]>) => {
            state.vacationsList = action.payload;
        },

        addVacation: (state, action: PayloadAction<VacationModel>) => {
            state.vacationsList.push(action.payload);
        },
        updateVacation: (state, action: PayloadAction<VacationModel>) => {
            const updatedVacation = { ...action.payload };
            state.vacationsList = state.vacationsList.filter(v => v.id !== action.payload.id).concat(updatedVacation);
        },
        deleteVacation: (state, action: PayloadAction<number>) => {
            state.vacationsList = state.vacationsList.filter(v => v.id !== action.payload);
        }
    }
})

export const { fetchVacations, addVacation, updateVacation, deleteVacation } = vacationsSlice.actions;
export default vacationsSlice.reducer;