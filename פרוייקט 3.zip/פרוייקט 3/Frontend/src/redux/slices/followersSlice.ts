import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import FollowersModel from "../../models/FollowersModel";

interface FollowersState {
    followers: FollowersModel[]; 
    countFollowers: number;
}

const initialState: FollowersState = {
    followers: [],
    countFollowers: 0,
};

const followersSlice = createSlice({
    name: "followers",
    initialState,
    reducers: {
        addFollower: (state, action: PayloadAction<FollowersModel>) => {
            state.followers.push(action.payload);
        },
        removeFollower: (state, action: PayloadAction<{ userId: number; vacationId: number }>) => {
            const { userId, vacationId } = action.payload;
            state.followers = state.followers.filter(
                (follower) => follower.userId !== userId || follower.vacationId !== vacationId
            );
        },
        setFollowers: (state, action: PayloadAction<FollowersModel[]>) => {
            state.followers = action.payload;
        },
    },
});

export const { addFollower, removeFollower, setFollowers } = followersSlice.actions;
export default followersSlice.reducer;
