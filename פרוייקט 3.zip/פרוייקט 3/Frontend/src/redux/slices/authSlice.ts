import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import UserModel from "../../models/UserModel";
import { parseJwt } from "../../utils/helpers";
import { jwtDecode } from "jwt-decode";

interface AuthState {
    token: string ;
    user: UserModel ;
}

const token = localStorage.getItem("token");
let decodedUser: UserModel = null;

if (token) {
    try {
        const container: { user: UserModel } = jwtDecode(token);
        decodedUser = container.user;
    } catch (error) {
        console.error("Token decoding failed:", error);
    }
}

const initialState: AuthState = {
    token: token ,
    user: decodedUser,
};

const authSlice = createSlice({
    name: "auth",
    initialState,
    reducers: {
        
        register: (state: AuthState, action: PayloadAction<string>) => {
            const token = action.payload;
            localStorage.setItem("token", token);
            const container: { userWithoutPassword: UserModel } = jwtDecode(token); 
            state.token = token;
            state.user = container.userWithoutPassword; 
        },
        login: (state: AuthState, action: PayloadAction<string>) => {
            const token = action.payload;
            localStorage.setItem("token", token);
            const container: { userWithoutPassword: UserModel } = jwtDecode(token); 
            state.token = token;
            state.user = container.userWithoutPassword; 
        },
        
        logout: (state: AuthState) => {
            state.token = null;
            state.user = null;
            localStorage.removeItem("token");
            localStorage.removeItem("user");
        },
        setUser: (state: AuthState, action: PayloadAction<UserModel | null>) => {
            state.user = action.payload; 
        },
    },
});

export const { register, login, logout, setUser } = authSlice.actions;
export default authSlice.reducer;