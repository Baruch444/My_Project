-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2024 at 02:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vacation`
--

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `user_id` int(11) NOT NULL,
  `vacation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `followers`
--

INSERT INTO `followers` (`user_id`, `vacation_id`) VALUES
(3, 2),
(3, 1),
(3, 11),
(3, 10),
(4, 1),
(4, 5),
(4, 12),
(6, 5),
(6, 1),
(6, 8),
(6, 2),
(6, 12),
(6, 14),
(5, 1),
(5, 8),
(5, 2),
(5, 4),
(5, 11),
(5, 12),
(5, 18),
(7, 1),
(7, 8),
(7, 9),
(7, 4),
(7, 5),
(8, 1),
(8, 8),
(8, 5),
(9, 5),
(9, 6),
(9, 1),
(9, 16),
(9, 14),
(9, 19),
(9, 8),
(9, 2),
(3, 9),
(3, 4),
(4, 7),
(4, 16),
(4, 8),
(10, 1),
(10, 6),
(10, 15),
(10, 12),
(10, 18),
(53, 1),
(53, 8);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `isAdmin` tinyint(1) DEFAULT 0,
  `token` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `isAdmin`, `token`) VALUES
(1, 'Baruch', 'Gavrielov', 'baruch@gmail.com', '$2b$10$MPZAeCOKIQRjr8VvhoRal..tqFPV/9YZj0hvU0N2XpJ.kvKeQa7mG', 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjoxLCJmaXJzdE5hbWUiOiJCYXJ1Y2giLCJsYXN0TmFtZSI6IkdhdnJpZWxvdiIsImVtYWlsIjoiYmFydWNoQGdtYWlsLmNvbSIsImlzQWRtaW4iOnRydWV9LCJpYXQiOjE3MzA3MjQyODZ9.T4NELI3q2dXPXWmjdCZtkpdItaw0PYvknBGu61fGRy0'),
(2, 'Bart', 'Simpson', 'bart@gmail.com', '$2b$10$gNXsp9a8hiAHNDDEyHgJzuGxuh5wnxisJST1IMFTv4aJi3bR4F3/S', 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjoyLCJmaXJzdE5hbWUiOiJCYXJ0IiwibGFzdE5hbWUiOiJTaW1wc29uIiwiZW1haWwiOiJiYXJ0QGdtYWlsLmNvbSIsImlzQWRtaW4iOnRydWV9LCJpYXQiOjE3MzA3MjQzMjJ9.E_LQKfxO5ls1gBJ25NTB6-9pZteNdWEJm4tYJJ4d9J0'),
(3, 'Patrick', 'Star', 'patrick@gmail.com', '$2b$10$oIj6Tea.f24o7RIufhrXHuhln1hl0S09a9HSYnjEH.lGHrPQfie3u', 0, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjozLCJmaXJzdE5hbWUiOiJQYXRyaWNrIiwibGFzdE5hbWUiOiJTdGFyIiwiZW1haWwiOiJwYXRyaWNrQGdtYWlsLmNvbSIsImlzQWRtaW4iOmZhbHNlfSwiaWF0IjoxNzMwNzI0MzQ0fQ.BApYW8nrYBFkWHuqmCZrGs5FWNoIjYN53C9AChAtO7g'),
(4, 'Yaba', 'Daba', 'yaba@gmail.com', '$2b$10$FLDOmgJbXp8OHoOjD3zZXuyh7pc3YoGnDs4944V7PdOv7MPb3DK/G', 0, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjo0LCJmaXJzdE5hbWUiOiJZYWJhIiwibGFzdE5hbWUiOiJEYWJhIiwiZW1haWwiOiJ5YWJhQGdtYWlsLmNvbSIsImlzQWRtaW4iOmZhbHNlfSwiaWF0IjoxNzMwNzI0MzY3fQ.MiqZy5MEUcAQqVkUIEZIHb8328K82x9jMYizX4mWPfI'),
(5, 'Bob', 'Marley', 'bob@gmail.com', '$2b$10$R.zs/1OKMWBs7yT.YsVks.ddDGLs0s4ntODn1a6rndmnkEAv25gka', 0, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjo1LCJmaXJzdE5hbWUiOiJCb2IiLCJsYXN0TmFtZSI6Ik1hcmxleSIsImVtYWlsIjoiYm9iQGdtYWlsLmNvbSIsImlzQWRtaW4iOmZhbHNlfSwiaWF0IjoxNzMwNzI0NDAxfQ.z4kTA-fbFiXg4mya8yJNBem3IOG_TN-0BpLe6nDirbM'),
(6, 'Homer', 'Simpson', 'homer@gmail.com', '$2b$10$ZAIn7qS8St9qN826VeE0ueH4.OCXNcTMwE5UYUpzhomB5O8PuIq8q', 0, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjo2LCJmaXJzdE5hbWUiOiJIb21lciIsImxhc3ROYW1lIjoiU2ltcHNvbiIsImVtYWlsIjoiaG9tZXJAZ21haWwuY29tIiwiaXNBZG1pbiI6ZmFsc2V9LCJpYXQiOjE3MzA3MzM4MzR9.O23YzmEADsTKcDVThrkKgXEsf4NyP9ii7bj9vRpkSLQ'),
(7, 'Lisa', 'Simpson', 'lisa@gmail.com', '$2b$10$F2jwbpztP06VhhzaoIthBevV0n9d4WFu/1kzKLuYr0Quwm7RKZN26', 0, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjo3LCJmaXJzdE5hbWUiOiJMaXNhIiwibGFzdE5hbWUiOiJTaW1wc29uIiwiZW1haWwiOiJsaXNhQGdtYWlsLmNvbSIsImlzQWRtaW4iOmZhbHNlfSwiaWF0IjoxNzMwODA4MTExfQ.zJ_Kjp1iXJCS8OAMPr9iEbwwv5pyXJrfhk5SL4BWOKY'),
(8, 'Snoop', 'Dog', 'snoop@gmail.com', '$2b$10$Z1LsrkITPh8KgLJ7Dvc1XumhHPQ0eUWhtErnqL2rsK//i.L37aNJS', 0, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjo4LCJmaXJzdE5hbWUiOiJTbm9vcCIsImxhc3ROYW1lIjoiRG9nIiwiZW1haWwiOiJzbm9vcEBnbWFpbC5jb20iLCJpc0FkbWluIjpmYWxzZX0sImlhdCI6MTczMDg4MjE4Nn0.-mIC_Gu0W-z1hiR_1WF_0HU4pn6ft8tO4U0NEaYVfcQ'),
(9, 'Maggie', 'Simpson', 'maggie@gmail.com', '$2b$10$FufLf36cfWofVyb2GIUXTuEUGNjijowL1rXcIfT6uGqNMa1Rlmniu', 0, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjo5LCJmaXJzdE5hbWUiOiJNYWdnaWUiLCJsYXN0TmFtZSI6IlNpbXBzb24iLCJlbWFpbCI6Im1hZ2dpZUBnbWFpbC5jb20iLCJpc0FkbWluIjpmYWxzZX0sImlhdCI6MTczMTM5MzgyNX0.Hjf6fwJFewUOx8W2Y1By4IwkgBO484zUc550rW5vjsM'),
(10, 'Marge', 'Simpson', 'marge@gmail.com', '$2b$10$NSs0a2tUO.IfBe6gjtcKBee.ViYRcRmb0r2W.7Fvcq8mor0ZaKuy2', 0, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjoxMCwiZmlyc3ROYW1lIjoiTWFyZ2UiLCJsYXN0TmFtZSI6IlNpbXBzb24iLCJlbWFpbCI6Im1hcmdlQGdtYWlsLmNvbSIsImlzQWRtaW4iOmZhbHNlfSwiaWF0IjoxNzMxNDI1OTU0fQ.kKQsJju7uk0EjiaLuZNbUzAJDlBbR7WmPhIk12Gfdqc'),
(53, 'Bar', 'Barbanel', 'bar@gmail.com', '$2b$10$Sg5GTdrOv0sKVCVp4PAb3O84b0JpreHIsJNq0xZojV9Og0BzFSdBq', 0, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyV2l0aG91dFBhc3N3b3JkIjp7ImlkIjo1MywiZmlyc3ROYW1lIjoiQmFyIiwibGFzdE5hbWUiOiJCYXJiYW5lbCIsImVtYWlsIjoiYmFyQGdtYWlsLmNvbSIsImlzQWRtaW4iOmZhbHNlfSwiaWF0IjoxNzMxNzg0MjIyfQ.-yDUOi-5TpZj5e6cuhPk4WiO6lep0UiGaJ-Ky7ZuatI');

-- --------------------------------------------------------

--
-- Table structure for table `vacations`
--

CREATE TABLE `vacations` (
  `id` int(11) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vacations`
--

INSERT INTO `vacations` (`id`, `destination`, `description`, `start_date`, `end_date`, `price`) VALUES
(1, 'Tokyo', 'Tokyo, Japan\'s bustling capital, blends ultramodern innovation with traditional culture. Known for its towering skyscrapers, historic temples like Senso-ji, and vibrant neighborhoods such as Shibuya and Akihabara, it offers endless attractions. From world-class sushi to serene gardens, Tokyo is a dynamic hub of technology, fashion, and rich cultural heritage.', '2024-11-12', '2024-11-21', 2000.00),
(2, 'Paris', 'Paris, the capital of France, is renowned for its rich history, art, and culture. Famous landmarks include the Eiffel Tower, Notre-Dame Cathedral, and the Louvre Museum. Known as the \"City of Light,\" Paris offers stunning architecture, world-class cuisine, and vibrant fashion, making it a global center of tourism and innovation.', '2024-11-15', '2024-11-30', 1000.00),
(3, 'Istanbul', 'Istanbul, a city bridging Europe and Asia, is celebrated for its rich history and diverse culture. Famous for landmarks like the Hagia Sophia, Blue Mosque, and Grand Bazaar, it offers a blend of ancient and modern. Its vibrant streets, scenic Bosphorus views, and unique culinary scene captivate visitors worldwide.', '2025-01-16', '2025-01-31', 400.00),
(4, 'Rome', 'Rome, Italy\'s capital, is a city steeped in history, boasting ancient ruins like the Colosseum, Roman Forum, and Pantheon. Known as the \"Eternal City,\" it offers a blend of iconic landmarks, art, and architecture. With its charming piazzas, delicious cuisine, and vibrant atmosphere, Rome is a timeless cultural destination.', '2024-11-15', '2024-11-20', 500.00),
(5, 'London', 'London, the capital of the United Kingdom, is a global hub of culture, history, and commerce. Famous for landmarks like the Tower of London, Buckingham Palace, and the British Museum, it offers a rich mix of tradition and modernity. Its diverse neighborhoods, vibrant arts scene, and iconic red buses make it unforgettable.', '2024-11-13', '2024-11-28', 2300.00),
(6, 'New York', 'New York City, known as \"The Big Apple,\" is a vibrant, bustling metropolis famous for its iconic skyline, including the Empire State Building and Statue of Liberty. A global cultural hub, it offers world-class museums, Broadway shows, and diverse neighborhoods like Manhattan, Brooklyn, and Harlem, making it a city of endless opportunities.', '2024-11-13', '2024-11-21', 798.00),
(7, 'Sydney', 'Sydney, Australia’s largest city, is renowned for its stunning harbor, the iconic Sydney Opera House, and the Sydney Harbour Bridge. With beautiful beaches like Bondi and Manly, vibrant cultural scenes, and a laid-back outdoor lifestyle, Sydney combines natural beauty with cosmopolitan living, offering a unique blend of relaxation and excitement.', '2024-11-12', '2024-11-21', 750.00),
(8, 'Dubai', 'Dubai, a dazzling city in the United Arab Emirates, is known for its futuristic skyline, luxury shopping, and remarkable architecture like the Burj Khalifa. Famous for its extravagant lifestyle, artificial islands, and vibrant cultural scene, Dubai offers a unique blend of tradition and modernity, attracting tourists and business travelers alike.', '2024-11-14', '2024-11-22', 1300.00),
(9, 'Barcelona', 'Barcelona, located on Spain’s Mediterranean coast, is renowned for its unique blend of modernist and Gothic architecture, with landmarks like the Sagrada Familia and Park Güell by Antoni Gaudí. The city\'s lively atmosphere, stunning beaches, rich history, and world-class art scene make it a vibrant destination for culture and leisure.', '2024-11-21', '2024-12-06', 457.00),
(10, 'Berlin', 'Berlin, Germanys capital, is a city rich in history and culture. Known for its landmarks like the Brandenburg Gate, Berlin Wall, and the Reichstag, it offers a vibrant arts scene, diverse neighborhoods, and a dynamic nightlife. The city seamlessly blends modern innovation with historical significance, making it a global cultural hub.', '2024-11-21', '2024-12-11', 4500.00),
(11, 'Amsterdam', 'Amsterdam, the capital of the Netherlands, is famous for its picturesque canals, historic architecture, and world-class museums like the Van Gogh Museum and Anne Frank House. Known for its vibrant culture, bike-friendly streets, and laid-back atmosphere, Amsterdam offers a unique blend of art, history, and modern living, making it a top European destination.', '2024-11-16', '2024-11-25', 598.00),
(12, 'Bangkok', 'Bangkok, the capital of Thailand, is a bustling metropolis known for its vibrant street life, ornate temples, and bustling markets. Famous for landmarks like the Grand Palace, Wat Arun, and Wat Pho, it combines rich cultural heritage with modern skyscrapers. The city\'s dynamic food scene and lively nightlife make it a global hotspot.', '2024-11-30', '2024-12-27', 8000.00),
(13, 'Los Angeles', 'Los Angeles, California, is a sprawling city known as the entertainment capital of the world. Home to Hollywood, iconic landmarks like the Hollywood Sign, and renowned beaches such as Venice and Santa Monica, LA is famous for its film industry, diverse culture, and vibrant arts scene, offering endless opportunities for exploration.', '2025-01-02', '2025-01-24', 840.00),
(14, 'Mexico City', 'Mexico City, the capital of Mexico, is a dynamic blend of ancient history and modern culture. Known for its rich Aztec heritage, landmarks like the Zócalo, Chapultepec Castle, and the Frida Kahlo Museum, the city offers a vibrant arts scene, delicious cuisine, and bustling markets, making it a cultural and historical hub.', '2024-11-29', '2024-12-06', 500.00),
(15, 'Athens', 'Athens, the capital of Greece, is a city steeped in ancient history and culture. Famous for iconic landmarks like the Acropolis, Parthenon, and Temple of Olympian Zeus, it offers a glimpse into the birthplace of democracy and Western civilization. With vibrant neighborhoods, delicious cuisine, and rich archaeological sites, Athens is a timeless cultural destination.', '2024-11-22', '2024-12-07', 550.00),
(16, 'Cairo', 'Cairo, the capital of Egypt, is a bustling metropolis known for its ancient history and vibrant culture. Famous for the nearby Pyramids of Giza and the Sphinx, the city offers rich Islamic architecture, lively markets like Khan El Khalili, and world-class museums, including the Egyptian Museum. Cairo is a dynamic blend of history and modernity.', '2024-11-21', '2024-11-29', 700.00),
(17, 'Moscow', 'Moscow, the capital of Russia, is a city rich in history and culture. Known for iconic landmarks like the Red Square, Kremlin, and St. Basil\'s Cathedral, it offers a blend of historic architecture and modern developments. The city is a political, economic, and cultural hub, with vibrant arts, theaters, and museums.', '2024-12-03', '2024-12-07', 897.00),
(18, 'Cape Town ', 'Cape Town Located in South Africa, Cape Town is known for its stunning natural beauty, including Table Mountain, beautiful beaches, and the Cape of Good Hope. With a vibrant cultural scene, historic landmarks like Robben Island, and a diverse culinary offering, Cape Town is a must-visit destination for nature lovers and adventurers.', '2024-12-19', '2025-01-11', 900.00),
(19, 'Rio de Janeiro', 'Rio de Janeiro, Brazil, is famous for its lively atmosphere, beautiful beaches like Copacabana and Ipanema, and the iconic Christ the Redeemer statue. Known for its Carnival celebrations, vibrant nightlife, and stunning landscapes, Rio is a dynamic blend of culture, music, and breathtaking natural beauty.', '2025-01-30', '2025-03-07', 8000.00),
(20, 'Lisbon', ' The capital of Portugal, Lisbon is known for its charming neighborhoods, including Alfama and Baixa, historic landmarks like the Belém Tower, and picturesque views of the Tagus River. With its vibrant cultural scene, delicious cuisine, and mild climate, Lisbon offers a unique blend of tradition and modernity.', '2024-11-28', '2024-12-07', 775.00);

-- --------------------------------------------------------

--
-- Table structure for table `vacations_image`
--

CREATE TABLE `vacations_image` (
  `id` int(11) NOT NULL,
  `vacation_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vacations_image`
--

INSERT INTO `vacations_image` (`id`, `vacation_id`, `image_path`) VALUES
(1, 1, '851e4e01-51b6-4ee3-9feb-5d83b269769c.jpeg'),
(2, 2, 'a800ba80-7c1b-4956-87a9-c6a204aec096.jpeg'),
(3, 3, '4feb80b1-c8f2-4a08-a5cb-fcb61ccaaf69.jpeg'),
(4, 4, '49a6ff04-6897-4f71-a4ee-ed73147b0030.jpeg'),
(5, 5, 'ad537377-7375-41ca-800a-c5426beefa70.jpeg'),
(6, 6, '36703a1f-3a3f-41aa-bd9d-f218773dce98.jpeg'),
(7, 7, '21117cba-de8e-4b83-83ce-e1e233730f26.jpeg'),
(8, 8, '2aba6033-cf05-4b5c-bc8e-6333a9147402.jpeg'),
(9, 9, '56c2a58f-765c-47ba-ba46-3e04d4a56fe2.jpeg'),
(10, 10, '64a293b3-26f9-492d-90b1-90b969ab62f1.jpeg'),
(11, 11, '2b3dd770-df23-40ed-87b1-51cb17df2bf6.jpeg'),
(12, 12, '98ceccb0-0965-485e-8ac2-3c85a83941be.jpeg'),
(13, 13, 'abd7c8db-65b0-4735-895f-2e26e32b2e13.jpeg'),
(14, 14, '0c6c034c-cbc9-4451-b1b4-7bb1084bf5f3.jpeg'),
(15, 15, '30c09462-6d25-4484-9f8e-c9bf995b0ae4.jpeg'),
(16, 16, 'db46d498-0709-4349-b3db-f259687532fc.jpeg'),
(17, 17, '0677cfc8-5c67-41fd-bc27-130a8c92b700.jpeg'),
(18, 18, 'f3c4211e-7b52-49c8-b088-6ccc80ea7698.jpeg'),
(19, 19, 'b65177f7-6323-47a5-b0e0-513db3a0ee0d.jpeg'),
(20, 20, 'c5184386-375a-49c0-a0ae-c5f705a08d93.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD KEY `user_id` (`user_id`),
  ADD KEY `vacation_id` (`vacation_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vacations`
--
ALTER TABLE `vacations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vacations_image`
--
ALTER TABLE `vacations_image`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vacation_id` (`vacation_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `vacations`
--
ALTER TABLE `vacations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `vacations_image`
--
ALTER TABLE `vacations_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `followers`
--
ALTER TABLE `followers`
  ADD CONSTRAINT `followers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `followers_ibfk_2` FOREIGN KEY (`vacation_id`) REFERENCES `vacations` (`id`);

--
-- Constraints for table `vacations_image`
--
ALTER TABLE `vacations_image`
  ADD CONSTRAINT `vacations_image_ibfk_1` FOREIGN KEY (`vacation_id`) REFERENCES `vacations` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
